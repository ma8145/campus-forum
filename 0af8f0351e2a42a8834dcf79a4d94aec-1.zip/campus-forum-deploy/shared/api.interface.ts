export type PostCategory =
  | 'delivery'
  | 'charge'
  | 'market'
  | 'lostfound'
  | 'chat'
  | 'expose'
  | 'findpeople'
  | 'love';

export const POST_CATEGORIES: {
  key: PostCategory | 'all';
  name: string;
  description: string;
}[] = [
  { key: 'all', name: '全部', description: '查看所有分区的帖子' },
  { key: 'delivery', name: '代拿快递', description: '帮拿快递、外卖、跑腿' },
  { key: 'charge', name: '代充电', description: '电瓶车充电、代充电费' },
  { key: 'market', name: '蚂蚁市场', description: '二手交易、闲置出售' },
  { key: 'lostfound', name: '失物招领', description: '丢东西、捡东西' },
  { key: 'chat', name: '吐槽闲聊', description: '校园日常、灌水' },
  { key: 'expose', name: '挂人', description: '曝光不文明行为、吐槽特定人' },
  { key: 'findpeople', name: '找人', description: '寻找失主、寻找特定的人、寻人启事' },
  { key: 'love', name: '恋爱', description: '脱单、表白、交友、恋爱相关' },
];

export interface ContactInfo {
  qq?: string;
  wechat?: string;
  phone?: string;
}

export interface Post {
  id: string;
  title: string;
  content: string;
  category: PostCategory;
  contactInfo: ContactInfo | null;
  authorUserId: string;
  authorNickname: string;
  createdAt: string;
  updatedAt: string;
  likeCount: number;
  commentCount: number;
  isLiked: boolean;
  isTop: boolean;
}

export interface PostListResponse {
  items: Post[];
  total: number;
  page: number;
  pageSize: number;
}

export interface CategoryCount {
  category: PostCategory;
  count: number;
}

export interface CreatePostRequest {
  title: string;
  content: string;
  category: PostCategory;
  contactInfo: ContactInfo;
}

export interface Comment {
  id: string;
  postId: string;
  userId: string;
  nickname: string;
  content: string;
  createdAt: string;
}

export interface CommentListResponse {
  items: Comment[];
  total: number;
}

export interface CreateCommentRequest {
  content: string;
}

export interface LikeStatus {
  isLiked: boolean;
  likeCount: number;
}

export interface SensitiveWord {
  id: string;
  word: string;
  createdAt: string;
}

export interface SensitiveWordListResponse {
  items: SensitiveWord[];
  total: number;
  page: number;
  pageSize: number;
}

export interface AdminLoginRequest {
  username: string;
  password: string;
}

export interface AdminLoginResponse {
  token: string;
  username: string;
}

export interface AdminPostListResponse {
  items: Post[];
  total: number;
  page: number;
  pageSize: number;
}

export interface AdminCommentListResponse {
  items: Comment[];
  total: number;
  page: number;
  pageSize: number;
}

export interface AuthUser {
  id: string;
  username: string;
  nickname: string;
}

export interface AuthResponse {
  token: string;
  user: AuthUser;
}

export interface RegisterRequest {
  username: string;
  nickname: string;
  password: string;
}

export interface LoginRequest {
  username: string;
  password: string;
}

export interface CurrentUserInfo {
  userId: string;
  username: string;
  nickname: string;
}

export interface ForumUser {
  id: string;
  username: string;
  nickname: string;
  createdAt: string;
  postCount: number;
}

export interface ForumUserListResponse {
  items: ForumUser[];
  total: number;
  page: number;
  pageSize: number;
}

export interface CreateUserRequest {
  username: string;
  nickname: string;
  password: string;
}

export interface ResetPasswordRequest {
  password: string;
}

export interface AdminStats {
  postCount: number;
  commentCount: number;
  sensitiveWordCount: number;
  userCount: number;
}
