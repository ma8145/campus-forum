# 工商行政管理学院 · 校园社区论坛

一个基于 NestJS + React + PostgreSQL 的全栈校园论坛应用，支持部署到自有服务器，完全脱离第三方平台托管。

## 功能特性

- **三种身份**：管理员、注册用户、访客
  - 管理员：后台管理（删帖、置顶、敏感词、添加用户）
  - 注册用户：发帖、评论、点赞
  - 访客：仅浏览，不能互动
- **8个分区**：代拿快递、代充电、蚂蚁市场、失物招领、吐槽闲聊、挂人、找人、恋爱
- 帖子置顶、评论、点赞
- 敏感词过滤（发帖和评论时自动拦截）
- 移动端适配：左上角汉堡菜单滑出分区列表
- 账号由管理员添加，不支持自助注册

## 技术栈

- **后端**: NestJS 10 + Drizzle ORM + PostgreSQL
- **前端**: React 19 + TypeScript + Vite + Tailwind CSS
- **认证**: JWT + bcrypt
- **部署**: Docker / PM2 / Render / 自有服务器

## 环境要求

- Node.js >= 22.0.0
- npm >= 10.0.0
- PostgreSQL >= 14（或使用 Docker）

---

## 快速开始（本地开发）

```bash
# 1. 安装依赖
npm install

# 2. 配置环境变量
cp .env.example .env
# 编辑 .env，填入数据库连接信息

# 3. 初始化数据库
psql -U postgres -d campus_forum -f init.sql

# 4. 启动开发服务器（前后端同时启动）
npm run dev
```

前端运行在 `http://localhost:5173`，后端 API 在 `http://localhost:3000/api`。

---

## 部署方案

### 方案一：Docker Compose（推荐，最简单）

适合有自己服务器的用户，一条命令启动整个应用。

```bash
# 1. 上传项目到服务器
scp -r campus-forum-deploy user@your-server:/opt/
cd /opt/campus-forum-deploy

# 2. 创建环境变量文件
cp .env.example .env
# 编辑 .env，修改 JWT_SECRET 和密码

# 3. 一键启动（自动构建 + 启动 PostgreSQL + 应用）
docker compose up -d --build

# 4. 查看日志
docker compose logs -f app
```

访问 `http://你的服务器IP:3000` 即可。

> 首次启动会自动执行 `init.sql` 建表。数据持久化在 Docker volume 中。

### 方案二：GitHub + 自动部署到服务器

#### 第一步：创建 GitHub 仓库

```bash
cd campus-forum-deploy
git init
git add .
git commit -m "init: campus forum"
git branch -M main
git remote add origin https://github.com/你的用户名/campus-forum.git
git push -u origin main
```

#### 第二步：服务器准备

在服务器上安装 Docker 和 Git，然后克隆仓库：

```bash
# 安装 Docker（Ubuntu）
curl -fsSL https://get.docker.com | sh
sudo usermod -aG docker $USER

# 克隆项目
mkdir -p /opt/campus-forum
cd /opt/campus-forum
git clone https://github.com/你的用户名/campus-forum.git .

# 创建 .env
cp .env.example .env
# 编辑 .env 修改密钥

# 首次启动
docker compose up -d --build
```

#### 第三步：配置 GitHub Actions 自动部署

在 GitHub 仓库 → Settings → Secrets and variables → Actions，添加以下 Secrets：

| Secret 名 | 说明 |
|-----------|------|
| `SERVER_HOST` | 服务器 IP 或域名 |
| `SERVER_USER` | SSH 登录用户名 |
| `SSH_PRIVATE_KEY` | SSH 私钥内容 |
| `SERVER_PORT` | SSH 端口（默认 22，可选） |

项目已包含 `.github/workflows/deploy.yml`，推送到 main 分支后会自动：
1. 构建测试
2. SSH 到服务器执行 `git pull && docker compose up -d --build`

#### 第四步：以后更新代码

```bash
# 本地修改后
git add .
git commit -m "fix: xxx"
git push
# GitHub Actions 会自动部署到服务器
```

### 方案三：Render 一键部署（免费额度）

适合没有服务器的用户，Render 提供免费套餐。

1. 将代码推送到 GitHub
2. 登录 [render.com](https://render.com)，用 GitHub 账号授权
3. 点击 "New +" → "Blueprint" → 选择你的仓库
4. Render 会自动读取 `render.yaml`，创建 PostgreSQL 数据库和 Web 服务
5. 等待部署完成，访问分配的域名

> 免费套餐会休眠，15分钟无请求后下次访问需等待约30秒唤醒。

### 方案四：PM2 原生部署（不使用 Docker）

```bash
# 1. 安装 Node.js 22
curl -fsSL https://deb.nodesource.com/setup_22.x | sudo -E bash -
sudo apt-get install -y nodejs

# 2. 安装 PostgreSQL
sudo apt-get install -y postgresql
sudo -u postgres psql -c "ALTER USER postgres PASSWORD '你的密码';"
sudo -u postgres psql -c "CREATE DATABASE campus_forum;"

# 3. 初始化数据库
psql -U postgres -d campus_forum -f init.sql

# 4. 安装依赖并构建
npm install
npm run build

# 5. 用 PM2 启动
npm install -g pm2
pm2 start dist/server/main.js --name campus-forum
pm2 startup && pm2 save
```

### Nginx 反向代理（可选，所有方案通用）

```nginx
server {
    listen 80;
    server_name 你的域名;

    location / {
        proxy_pass http://127.0.0.1:3000;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
    }
}
```

---

## 账号说明

### 管理员账号
- 登录地址：`http://你的域名/admin/login`
- 用户名：`123`
- 密码：`ma846486`
- 后台功能：帖子管理（删除/置顶）、评论管理、用户管理（添加/删除/重置密码）、敏感词管理

### 普通用户账号
- 不能自己注册，必须由管理员在后台添加
- 登录后可以发帖、评论、点赞

### 访客模式
- 登录页点击「以访客身份进入」
- 可以浏览帖子列表和详情
- 不能发帖、评论、点赞
- 点击互动按钮会提示登录

---

## 移动端使用

- 左上角三条杠按钮打开侧边栏
- 侧边栏显示所有分区，点击切换
- 底部显示当前登录身份（用户/访客），可快速切换登录

---

## 常用命令

```bash
# 构建
npm run build

# 开发模式
npm run dev

# 生产启动
npm start

# Docker
docker compose up -d --build    # 启动
docker compose down              # 停止
docker compose logs -f app       # 查看日志
docker compose restart app       # 重启应用

# PM2
pm2 restart campus-forum
pm2 logs campus-forum
```

---

## 项目结构

```
campus-forum-deploy/
├── .github/workflows/deploy.yml  # GitHub Actions 自动部署
├── client/                       # 前端源码
│   └── src/
│       ├── api/                  # API 请求层
│       ├── components/           # 组件（Header/Sidebar/MobileDrawer/PostCard等）
│       ├── hooks/                # useAuth/useAdminAuth
│       ├── pages/                # 页面（首页/帖子详情/发帖/登录/管理员后台）
│       ├── app.tsx               # 路由
│       └── main.tsx              # 入口
├── server/                       # 后端源码
│   ├── common/guards/            # JWT守卫 + 可选JWT守卫（访客模式）
│   ├── modules/                  # auth/forum/admin/view
│   ├── app.module.ts
│   └── main.ts
├── shared/                       # 前后端共享类型
├── init.sql                      # 数据库建表脚本
├── Dockerfile                    # Docker 镜像
├── docker-compose.yml            # Docker Compose 编排
├── render.yaml                   # Render 一键部署
├── .env.example                  # 环境变量模板
├── .gitignore
└── README.md
```

---

## 常见问题

### 1. 部署后页面空白/404
确保 `npm run build` 成功，`dist/client/index.html` 存在。Docker 部署会自动构建。

### 2. 数据库连接失败
检查 `.env` 中 `DATABASE_URL`，Docker 部署时主机名是 `postgres` 而非 `localhost`。

### 3. 管理员登录失败
确认 `ADMIN_USERNAME` 和 `ADMIN_PASSWORD` 环境变量已设置。Docker Compose 默认值是 `123` / `ma846486`。

### 4. 访客能看到帖子但不能点赞
这是正常设计。访客只能浏览，登录后才能互动。

### 5. 如何修改管理员密码
修改 `.env` 中的 `ADMIN_PASSWORD`，然后重启应用（`docker compose restart app` 或 `pm2 restart`）。

### 6. 如何添加分区
编辑 `shared/api.interface.ts` 中的 `POST_CATEGORIES` 数组，重新构建部署即可。
