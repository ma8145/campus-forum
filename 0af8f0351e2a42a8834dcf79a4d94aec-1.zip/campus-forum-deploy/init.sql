-- ============================================
-- 工商行政管理学院校园论坛 数据库初始化脚本
-- 数据库: PostgreSQL 14+
-- ============================================

-- 启用 UUID 扩展
CREATE EXTENSION IF NOT EXISTS "pgcrypto";

-- ============================================
-- 用户表
-- ============================================
CREATE TABLE IF NOT EXISTS forum_users (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  username varchar(50) NOT NULL UNIQUE,
  nickname varchar(100) NOT NULL,
  password varchar(255) NOT NULL,
  _created_at TIMESTAMP(3) WITH TIME ZONE NOT NULL DEFAULT CURRENT_TIMESTAMP,
  _updated_at TIMESTAMP(3) WITH TIME ZONE NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE UNIQUE INDEX IF NOT EXISTS forum_users_username_key ON forum_users (username);
CREATE INDEX IF NOT EXISTS idx_forum_users_username ON forum_users (username);

-- ============================================
-- 帖子表
-- ============================================
CREATE TABLE IF NOT EXISTS posts (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  title varchar(200) NOT NULL,
  content text NOT NULL,
  category varchar(50) NOT NULL,
  contact_info jsonb,
  author_user_id varchar(255) NOT NULL,
  author_nickname varchar(100) NOT NULL,
  is_top BOOLEAN NOT NULL DEFAULT false,
  _created_at TIMESTAMP(3) WITH TIME ZONE NOT NULL DEFAULT CURRENT_TIMESTAMP,
  _updated_at TIMESTAMP(3) WITH TIME ZONE NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX IF NOT EXISTS idx_posts_category ON posts (category);
CREATE INDEX IF NOT EXISTS idx_posts_created_at ON posts (_created_at);
CREATE INDEX IF NOT EXISTS idx_posts_author_user_id ON posts (author_user_id);
CREATE INDEX IF NOT EXISTS idx_posts_is_top ON posts (is_top);

-- ============================================
-- 评论表
-- ============================================
CREATE TABLE IF NOT EXISTS comments (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  post_id uuid NOT NULL REFERENCES posts(id) ON DELETE CASCADE,
  user_id varchar(255) NOT NULL,
  nickname varchar(100) NOT NULL,
  content text NOT NULL,
  _created_at TIMESTAMP(3) WITH TIME ZONE NOT NULL DEFAULT CURRENT_TIMESTAMP,
  _updated_at TIMESTAMP(3) WITH TIME ZONE NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX IF NOT EXISTS idx_comments_post_id ON comments (post_id);
CREATE INDEX IF NOT EXISTS idx_comments_created_at ON comments (_created_at);
CREATE INDEX IF NOT EXISTS idx_comments_user_id ON comments (user_id);

-- ============================================
-- 点赞表
-- ============================================
CREATE TABLE IF NOT EXISTS likes (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  post_id uuid NOT NULL REFERENCES posts(id) ON DELETE CASCADE,
  user_id varchar(255) NOT NULL,
  _created_at TIMESTAMP(3) WITH TIME ZONE NOT NULL DEFAULT CURRENT_TIMESTAMP,
  _updated_at TIMESTAMP(3) WITH TIME ZONE NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE UNIQUE INDEX IF NOT EXISTS idx_likes_post_user ON likes (post_id, user_id);
CREATE INDEX IF NOT EXISTS idx_likes_post_id ON likes (post_id);
CREATE INDEX IF NOT EXISTS idx_likes_user_id ON likes (user_id);

-- ============================================
-- 敏感词表
-- ============================================
CREATE TABLE IF NOT EXISTS sensitive_words (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  word varchar(100) NOT NULL UNIQUE,
  _created_at TIMESTAMP(3) WITH TIME ZONE NOT NULL DEFAULT CURRENT_TIMESTAMP,
  _updated_at TIMESTAMP(3) WITH TIME ZONE NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE UNIQUE INDEX IF NOT EXISTS sensitive_words_word_key ON sensitive_words (word);

-- 初始敏感词
INSERT INTO sensitive_words (word) VALUES
  ('垃圾'), ('作弊'), ('骗子'), ('黄牛'), ('代考')
ON CONFLICT (word) DO NOTHING;

-- ============================================
-- 初始化完成提示
-- ============================================
-- 数据库表创建完成！
-- 管理员账号: 123 / ma846486 (硬编码在 server/modules/admin/admin.service.ts)
-- 普通用户账号由管理员在后台添加
