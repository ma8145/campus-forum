import {
  Injectable,
  CanActivate,
  ExecutionContext,
  UnauthorizedException,
} from '@nestjs/common';
import { AuthService } from '@server/modules/auth/auth.service';

export interface CurrentUserInfo {
  userId: string;
  username: string;
  nickname: string;
}

@Injectable()
export class JwtAuthGuard implements CanActivate {
  constructor(private readonly authService: AuthService) {}

  canActivate(context: ExecutionContext): boolean {
    const request = context.switchToHttp().getRequest();
    const authHeader: string | undefined = request.headers.authorization;

    if (!authHeader || !authHeader.startsWith('Bearer ')) {
      throw new UnauthorizedException('未提供认证令牌');
    }

    const token: string = authHeader.slice(7);
    const payload = this.authService.verifyToken(token);

    if (!payload) {
      throw new UnauthorizedException('认证令牌无效或已过期');
    }

    request.user = {
      userId: payload.sub,
      username: payload.username,
      nickname: payload.nickname,
    } as CurrentUserInfo;

    return true;
  }
}
