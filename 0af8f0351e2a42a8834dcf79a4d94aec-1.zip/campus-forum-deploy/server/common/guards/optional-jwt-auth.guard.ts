import { Injectable, CanActivate, ExecutionContext } from '@nestjs/common';
import { AuthService } from '@server/modules/auth/auth.service';

@Injectable()
export class OptionalJwtAuthGuard implements CanActivate {
  constructor(private readonly authService: AuthService) {}

  canActivate(context: ExecutionContext): boolean {
    const request = context.switchToHttp().getRequest();
    const authHeader: string | undefined = request.headers.authorization;

    if (!authHeader || !authHeader.startsWith('Bearer ')) {
      request.user = null;
      return true;
    }

    const token = authHeader.substring(7);
    const payload = this.authService.verifyToken(token);

    if (!payload) {
      request.user = null;
      return true;
    }

    request.user = {
      userId: payload.sub,
      username: payload.username,
      nickname: payload.nickname,
    };

    return true;
  }
}
