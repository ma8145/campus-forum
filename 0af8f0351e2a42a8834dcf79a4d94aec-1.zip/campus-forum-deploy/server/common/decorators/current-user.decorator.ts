import { createParamDecorator, ExecutionContext } from '@nestjs/common';
import type { CurrentUserInfo } from '../guards/jwt-auth.guard';

export const CurrentUser = createParamDecorator(
  (_data: unknown, ctx: ExecutionContext): CurrentUserInfo | undefined => {
    const request = ctx.switchToHttp().getRequest();
    return request.user as CurrentUserInfo | undefined;
  },
);
