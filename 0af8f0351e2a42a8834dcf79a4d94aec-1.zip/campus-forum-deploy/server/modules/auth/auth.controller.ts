import {
  Controller,
  Post,
  Get,
  Body,
  UseGuards,
  BadRequestException,
} from '@nestjs/common';
import { AuthService } from './auth.service';
import { JwtAuthGuard } from '@server/common/guards/jwt-auth.guard';
import { CurrentUser } from '@server/common/decorators/current-user.decorator';
import type {
  AuthUser,
  AuthResponse,
  LoginRequest,
  CurrentUserInfo,
} from '@shared/api.interface';

@Controller('api/auth')
export class AuthController {
  constructor(private readonly authService: AuthService) {}

  @Post('login')
  async login(@Body() dto: LoginRequest): Promise<AuthResponse> {
    if (!dto.username || !dto.password) {
      throw new BadRequestException('用户名和密码不能为空');
    }
    return this.authService.login(dto);
  }

  @Get('me')
  @UseGuards(JwtAuthGuard)
  async me(@CurrentUser() user: CurrentUserInfo): Promise<AuthUser> {
    return this.authService.getMe(user.userId);
  }
}
