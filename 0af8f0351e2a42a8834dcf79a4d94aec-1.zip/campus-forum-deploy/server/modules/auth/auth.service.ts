import {
  Inject,
  Injectable,
  Logger,
  ConflictException,
  UnauthorizedException,
  NotFoundException,
} from '@nestjs/common';
import { DRIZZLE_DATABASE, type PostgresJsDatabase } from '@server/database/drizzle.module';
import { eq } from 'drizzle-orm';
import * as bcrypt from 'bcrypt';
import * as jwt from 'jsonwebtoken';
import type { Secret, SignOptions } from 'jsonwebtoken';
import { forumUsers } from '@server/database/schema';
import type {
  AuthUser,
  AuthResponse,
  RegisterRequest,
  LoginRequest,
} from '@shared/api.interface';

interface JwtPayload {
  sub: string;
  username: string;
  nickname: string;
}

const JWT_SECRET: Secret = process.env.JWT_SECRET || 'campus-forum-jwt-secret';
const JWT_EXPIRES_IN = (process.env.JWT_EXPIRES_IN || '7d') as SignOptions['expiresIn'];
const BCRYPT_SALT_ROUNDS: number = 10;

@Injectable()
export class AuthService {
  private readonly logger = new Logger(AuthService.name);

  constructor(@Inject(DRIZZLE_DATABASE) private readonly db: PostgresJsDatabase) {}

  private generateToken(userId: string, username: string, nickname: string): string {
    const payload: JwtPayload = { sub: userId, username, nickname };
    const signOptions: SignOptions = { expiresIn: JWT_EXPIRES_IN };
    return jwt.sign(payload, JWT_SECRET, signOptions);
  }

  async register(dto: RegisterRequest): Promise<AuthResponse> {
    const { username, nickname, password } = dto;

    const existing = await this.db
      .select({ id: forumUsers.id })
      .from(forumUsers)
      .where(eq(forumUsers.username, username))
      .limit(1);

    if (existing.length > 0) {
      throw new ConflictException('用户名已存在');
    }

    const hashedPassword: string = await bcrypt.hash(password, BCRYPT_SALT_ROUNDS);

    const inserted = await this.db
      .insert(forumUsers)
      .values({
        username,
        nickname,
        password: hashedPassword,
      })
      .returning({ id: forumUsers.id, username: forumUsers.username, nickname: forumUsers.nickname });

    if (inserted.length === 0) {
      throw new ConflictException('注册失败');
    }

    const user: AuthUser = {
      id: inserted[0].id,
      username: inserted[0].username,
      nickname: inserted[0].nickname,
    };
    const token: string = this.generateToken(user.id, user.username, user.nickname);

    return { token, user };
  }

  async login(dto: LoginRequest): Promise<AuthResponse> {
    const { username, password } = dto;

    const rows = await this.db
      .select({
        id: forumUsers.id,
        username: forumUsers.username,
        nickname: forumUsers.nickname,
        password: forumUsers.password,
      })
      .from(forumUsers)
      .where(eq(forumUsers.username, username))
      .limit(1);

    if (rows.length === 0) {
      throw new UnauthorizedException('用户名或密码错误');
    }

    const row = rows[0];
    const isPasswordValid: boolean = await bcrypt.compare(password, row.password);

    if (!isPasswordValid) {
      throw new UnauthorizedException('用户名或密码错误');
    }

    const user: AuthUser = {
      id: row.id,
      username: row.username,
      nickname: row.nickname,
    };
    const token: string = this.generateToken(user.id, user.username, user.nickname);

    return { token, user };
  }

  async getMe(userId: string): Promise<AuthUser> {
    const rows = await this.db
      .select({
        id: forumUsers.id,
        username: forumUsers.username,
        nickname: forumUsers.nickname,
      })
      .from(forumUsers)
      .where(eq(forumUsers.id, userId))
      .limit(1);

    if (rows.length === 0) {
      throw new NotFoundException('用户不存在');
    }

    return {
      id: rows[0].id,
      username: rows[0].username,
      nickname: rows[0].nickname,
    };
  }

  verifyToken(token: string): JwtPayload | null {
    try {
      const decoded = jwt.verify(token, JWT_SECRET) as JwtPayload;
      return decoded;
    } catch {
      return null;
    }
  }
}
