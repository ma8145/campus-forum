import {
  Inject,
  Injectable,
  Logger,
  NotFoundException,
  BadRequestException,
  ConflictException,
  UnauthorizedException,
} from '@nestjs/common';
import { DRIZZLE_DATABASE, type PostgresJsDatabase } from '@server/database/drizzle.module';
import { eq, count, desc, sql } from 'drizzle-orm';
import * as bcrypt from 'bcrypt';
import { posts, comments, sensitiveWords, likes, forumUsers } from '@server/database/schema';
import type {
  Post,
  PostCategory,
  PostListResponse,
  ContactInfo,
  Comment,
  CommentListResponse,
  AdminCommentListResponse,
  SensitiveWord,
  SensitiveWordListResponse,
  AdminLoginResponse,
  ForumUser,
  ForumUserListResponse,
  CreateUserRequest,
  AdminStats,
} from '@shared/api.interface';

const ADMIN_USERNAME = '123';
const ADMIN_PASSWORD = 'ma846486';
const ADMIN_TOKEN = Buffer.from(`${ADMIN_USERNAME}:${ADMIN_PASSWORD}`).toString('base64');

const BCRYPT_SALT_ROUNDS = 10;

const UUID_REGEX = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;

function validateUuid(id: string, label: string): void {
  if (!UUID_REGEX.test(id)) {
    throw new BadRequestException(`无效的${label}ID格式`);
  }
}

interface AdminPostRow {
  id: string;
  title: string;
  content: string;
  category: string;
  contactInfo: unknown;
  authorUserId: string;
  authorNickname: string;
  isTop: boolean;
  createdAt: Date;
  updatedAt: Date;
  likeCount: number | string;
  commentCount: number | string;
  isLiked: boolean | null;
}

interface AdminCommentRow {
  id: string;
  postId: string;
  userId: string;
  nickname: string;
  content: string;
  createdAt: Date;
}

interface SensitiveWordRow {
  id: string;
  word: string;
  createdAt: Date;
}

interface ForumUserRow {
  id: string;
  username: string;
  nickname: string;
  createdAt: Date;
  postCount: number | string;
}

@Injectable()
export class AdminService {
  private readonly logger = new Logger(AdminService.name);

  constructor(@Inject(DRIZZLE_DATABASE) private readonly db: PostgresJsDatabase) {}

  validateAdminToken(token: string | undefined): boolean {
    return token === ADMIN_TOKEN;
  }

  login(username: string, password: string): AdminLoginResponse {
    if (username === ADMIN_USERNAME && password === ADMIN_PASSWORD) {
      return {
        token: ADMIN_TOKEN,
        username: ADMIN_USERNAME,
      };
    }
    throw new UnauthorizedException('用户名或密码错误');
  }

  private toPost(row: AdminPostRow): Post {
    return {
      id: row.id,
      title: row.title,
      content: row.content,
      category: row.category as PostCategory,
      contactInfo: row.contactInfo as ContactInfo | null,
      authorUserId: row.authorUserId,
      authorNickname: row.authorNickname,
      isTop: Boolean(row.isTop),
      createdAt: row.createdAt.toISOString(),
      updatedAt: row.updatedAt.toISOString(),
      likeCount: Number(row.likeCount),
      commentCount: Number(row.commentCount),
      isLiked: false,
    };
  }

  private buildPostSelect() {
    const likeCountSubquery = sql<number>`(
      SELECT count(*) FROM ${likes} WHERE ${likes.postId} = ${posts.id}
    )`;
    const commentCountSubquery = sql<number>`(
      SELECT count(*) FROM ${comments} WHERE ${comments.postId} = ${posts.id}
    )`;

    return {
      id: posts.id,
      title: posts.title,
      content: posts.content,
      category: posts.category,
      contactInfo: posts.contactInfo,
      authorUserId: posts.authorUserId,
      authorNickname: posts.authorNickname,
      isTop: posts.isTop,
      createdAt: posts.createdAt,
      updatedAt: posts.updatedAt,
      likeCount: likeCountSubquery,
      commentCount: commentCountSubquery,
      isLiked: sql<boolean>`false`,
    };
  }

  async getPostList(page: number, pageSize: number): Promise<PostListResponse> {
    const pageNum = Math.max(1, page);
    const pageSizeNum = Math.max(1, Math.min(50, pageSize));
    const offset = (pageNum - 1) * pageSizeNum;

    const selectCols = this.buildPostSelect();

    const [rows, countResult] = await Promise.all([
      this.db
        .select(selectCols)
        .from(posts)
        .orderBy(desc(posts.isTop), desc(posts.createdAt))
        .limit(pageSizeNum)
        .offset(offset),
      this.db.select({ count: count() }).from(posts),
    ]);

    const total = Number(countResult[0]?.count ?? 0);
    const items: Post[] = rows.map((row: AdminPostRow) => this.toPost(row));

    return {
      items,
      total,
      page: pageNum,
      pageSize: pageSizeNum,
    };
  }

  async deletePost(id: string): Promise<void> {
    validateUuid(id, '帖子');

    const deleted = await this.db
      .delete(posts)
      .where(eq(posts.id, id))
      .returning({ id: posts.id });

    if (deleted.length === 0) {
      throw new NotFoundException('帖子不存在');
    }

    this.logger.log(`管理员删除帖子: ${id}`);
  }

  async toggleTop(id: string, isTop: boolean): Promise<void> {
    validateUuid(id, '帖子');

    const now = new Date();
    const updated = await this.db
      .update(posts)
      .set({ isTop, updatedAt: now })
      .where(eq(posts.id, id))
      .returning({ id: posts.id });

    if (updated.length === 0) {
      throw new NotFoundException('帖子不存在');
    }

    this.logger.log(`管理员${isTop ? '置顶' : '取消置顶'}帖子: ${id}`);
  }

  private toComment(row: AdminCommentRow): Comment {
    return {
      id: row.id,
      postId: row.postId,
      userId: row.userId,
      nickname: row.nickname,
      content: row.content,
      createdAt: row.createdAt.toISOString(),
    };
  }

  async getCommentList(
    page: number,
    pageSize: number,
  ): Promise<AdminCommentListResponse> {
    const pageNum = Math.max(1, page);
    const pageSizeNum = Math.max(1, Math.min(50, pageSize));
    const offset = (pageNum - 1) * pageSizeNum;

    const [rows, countResult] = await Promise.all([
      this.db
        .select()
        .from(comments)
        .orderBy(desc(comments.createdAt))
        .limit(pageSizeNum)
        .offset(offset),
      this.db.select({ count: count() }).from(comments),
    ]);

    const total = Number(countResult[0]?.count ?? 0);
    const items: Comment[] = rows.map((row: AdminCommentRow) => this.toComment(row));

    return {
      items,
      total,
      page: pageNum,
      pageSize: pageSizeNum,
    };
  }

  async deleteComment(id: string): Promise<void> {
    validateUuid(id, '评论');

    const deleted = await this.db
      .delete(comments)
      .where(eq(comments.id, id))
      .returning({ id: comments.id });

    if (deleted.length === 0) {
      throw new NotFoundException('评论不存在');
    }

    this.logger.log(`管理员删除评论: ${id}`);
  }

  private toSensitiveWord(row: SensitiveWordRow): SensitiveWord {
    return {
      id: row.id,
      word: row.word,
      createdAt: row.createdAt.toISOString(),
    };
  }

  async getSensitiveWordList(
    page: number,
    pageSize: number,
  ): Promise<SensitiveWordListResponse> {
    const pageNum = Math.max(1, page);
    const pageSizeNum = Math.max(1, Math.min(50, pageSize));
    const offset = (pageNum - 1) * pageSizeNum;

    const [rows, countResult] = await Promise.all([
      this.db
        .select()
        .from(sensitiveWords)
        .orderBy(desc(sensitiveWords.createdAt))
        .limit(pageSizeNum)
        .offset(offset),
      this.db.select({ count: count() }).from(sensitiveWords),
    ]);

    const total = Number(countResult[0]?.count ?? 0);
    const items: SensitiveWord[] = rows.map((row: SensitiveWordRow) =>
      this.toSensitiveWord(row),
    );

    return { items, total, page: pageNum, pageSize: pageSizeNum };
  }

  async addSensitiveWord(word: string): Promise<SensitiveWord> {
    if (!word || !word.trim()) {
      throw new BadRequestException('敏感词不能为空');
    }

    const trimmed = word.trim();

    const existing = await this.db
      .select({ id: sensitiveWords.id })
      .from(sensitiveWords)
      .where(eq(sensitiveWords.word, trimmed))
      .limit(1);

    if (existing.length > 0) {
      throw new ConflictException('敏感词已存在');
    }

    const now = new Date();
    try {
      const inserted = await this.db
        .insert(sensitiveWords)
        .values({
          word: trimmed,
          createdAt: now,
          updatedAt: now,
        })
        .returning();

      if (inserted.length === 0) {
        throw new BadRequestException('添加敏感词失败');
      }

      return this.toSensitiveWord(inserted[0] as SensitiveWordRow);
    } catch (error: unknown) {
      const code = this.extractPostgresErrorCode(error);
      if (code === '23505') {
        throw new ConflictException('敏感词已存在');
      }
      throw error;
    }
  }

  async deleteSensitiveWord(id: string): Promise<void> {
    validateUuid(id, '敏感词');

    const deleted = await this.db
      .delete(sensitiveWords)
      .where(eq(sensitiveWords.id, id))
      .returning({ id: sensitiveWords.id });

    if (deleted.length === 0) {
      throw new NotFoundException('敏感词不存在');
    }

    this.logger.log(`管理员删除敏感词: ${id}`);
  }

  private toForumUser(row: ForumUserRow): ForumUser {
    return {
      id: row.id,
      username: row.username,
      nickname: row.nickname,
      createdAt: row.createdAt.toISOString(),
      postCount: Number(row.postCount),
    };
  }

  async getUserList(page: number, pageSize: number): Promise<ForumUserListResponse> {
    const pageNum = Math.max(1, page);
    const pageSizeNum = Math.max(1, Math.min(50, pageSize));
    const offset = (pageNum - 1) * pageSizeNum;

    const postCountSubquery = sql<number>`(
      SELECT count(*) FROM ${posts} WHERE ${posts.authorUserId} = ${forumUsers.id}::text
    )`;

    const [rows, countResult] = await Promise.all([
      this.db
        .select({
          id: forumUsers.id,
          username: forumUsers.username,
          nickname: forumUsers.nickname,
          createdAt: forumUsers.createdAt,
          postCount: postCountSubquery,
        })
        .from(forumUsers)
        .orderBy(desc(forumUsers.createdAt))
        .limit(pageSizeNum)
        .offset(offset),
      this.db.select({ count: count() }).from(forumUsers),
    ]);

    const total = Number(countResult[0]?.count ?? 0);
    const items: ForumUser[] = rows.map((row: ForumUserRow) => this.toForumUser(row));

    return { items, total, page: pageNum, pageSize: pageSizeNum };
  }

  async createUser(dto: CreateUserRequest): Promise<ForumUser> {
    const { username, nickname, password } = dto;

    if (!username || username.length < 3 || username.length > 20) {
      throw new BadRequestException('用户名长度需在3-20字符之间');
    }
    if (!nickname || nickname.length < 1 || nickname.length > 20) {
      throw new BadRequestException('昵称长度需在1-20字符之间');
    }
    if (!password || password.length < 6 || password.length > 50) {
      throw new BadRequestException('密码长度需在6-50字符之间');
    }

    const existing = await this.db
      .select({ id: forumUsers.id })
      .from(forumUsers)
      .where(eq(forumUsers.username, username.trim()))
      .limit(1);

    if (existing.length > 0) {
      throw new ConflictException('用户名已存在');
    }

    const hashedPassword: string = await bcrypt.hash(password, BCRYPT_SALT_ROUNDS);
    const now = new Date();

    const inserted = await this.db
      .insert(forumUsers)
      .values({
        username: username.trim(),
        nickname: nickname.trim(),
        password: hashedPassword,
        createdAt: now,
        updatedAt: now,
      })
      .returning({
        id: forumUsers.id,
        username: forumUsers.username,
        nickname: forumUsers.nickname,
        createdAt: forumUsers.createdAt,
      });

    if (inserted.length === 0) {
      throw new BadRequestException('创建用户失败');
    }

    this.logger.log(`管理员创建用户: ${username}`);

    return {
      id: inserted[0].id,
      username: inserted[0].username,
      nickname: inserted[0].nickname,
      createdAt: inserted[0].createdAt.toISOString(),
      postCount: 0,
    };
  }

  async deleteUser(id: string): Promise<void> {
    validateUuid(id, '用户');

    const userExists = await this.db
      .select({ id: forumUsers.id })
      .from(forumUsers)
      .where(eq(forumUsers.id, id))
      .limit(1);

    if (userExists.length === 0) {
      throw new NotFoundException('用户不存在');
    }

    await this.db.transaction(async (tx) => {
      await tx.delete(comments).where(eq(comments.userId, id));
      await tx.delete(likes).where(eq(likes.userId, id));
      await tx.delete(posts).where(eq(posts.authorUserId, id));
      await tx.delete(forumUsers).where(eq(forumUsers.id, id));
    });

    this.logger.log(`管理员删除用户: ${id}`);
  }

  async resetPassword(id: string, newPassword: string): Promise<void> {
    validateUuid(id, '用户');

    if (!newPassword || newPassword.length < 6 || newPassword.length > 50) {
      throw new BadRequestException('密码长度需在6-50字符之间');
    }

    const hashedPassword: string = await bcrypt.hash(newPassword, BCRYPT_SALT_ROUNDS);
    const now = new Date();

    const updated = await this.db
      .update(forumUsers)
      .set({ password: hashedPassword, updatedAt: now })
      .where(eq(forumUsers.id, id))
      .returning({ id: forumUsers.id });

    if (updated.length === 0) {
      throw new NotFoundException('用户不存在');
    }

    this.logger.log(`管理员重置用户密码: ${id}`);
  }

  async getStats(): Promise<AdminStats> {
    const [postResult, commentResult, wordResult, userResult] = await Promise.all([
      this.db.select({ count: count() }).from(posts),
      this.db.select({ count: count() }).from(comments),
      this.db.select({ count: count() }).from(sensitiveWords),
      this.db.select({ count: count() }).from(forumUsers),
    ]);

    return {
      postCount: Number(postResult[0]?.count ?? 0),
      commentCount: Number(commentResult[0]?.count ?? 0),
      sensitiveWordCount: Number(wordResult[0]?.count ?? 0),
      userCount: Number(userResult[0]?.count ?? 0),
    };
  }

  private extractPostgresErrorCode(error: unknown): string | undefined {
    let current: unknown = error;
    for (let depth = 0; depth < 4 && current && typeof current === 'object'; depth += 1) {
      const { code, cause } = current as { code?: unknown; cause?: unknown };
      if (typeof code === 'string') return code;
      current = cause;
    }
    return undefined;
  }
}
