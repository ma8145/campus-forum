import {
  Controller,
  Get,
  Post,
  Put,
  Delete,
  Body,
  Param,
  Query,
  Headers,
  UnauthorizedException,
  BadRequestException,
} from '@nestjs/common';
import { AdminService } from './admin.service';
import type {
  AdminLoginRequest,
  AdminLoginResponse,
  AdminPostListResponse,
  AdminCommentListResponse,
  SensitiveWordListResponse,
  SensitiveWord,
  ForumUserListResponse,
  ForumUser,
  CreateUserRequest,
  ResetPasswordRequest,
  AdminStats,
} from '@shared/api.interface';

@Controller('api/admin')
export class AdminController {
  constructor(private readonly adminService: AdminService) {}

  private checkAdmin(adminToken: string | undefined): void {
    if (!this.adminService.validateAdminToken(adminToken)) {
      throw new UnauthorizedException('管理员认证失败');
    }
  }

  @Post('login')
  async login(@Body() dto: AdminLoginRequest): Promise<AdminLoginResponse> {
    return this.adminService.login(dto.username, dto.password);
  }

  @Post('logout')
  async logout(): Promise<void> {
    return;
  }

  @Get('stats')
  async getStats(
    @Headers('x-admin-token') adminToken: string,
  ): Promise<AdminStats> {
    this.checkAdmin(adminToken);
    return this.adminService.getStats();
  }

  @Get('posts')
  async getPostList(
    @Headers('x-admin-token') adminToken: string,
    @Query('page') page?: string,
    @Query('pageSize') pageSize?: string,
  ): Promise<AdminPostListResponse> {
    this.checkAdmin(adminToken);
    const pageNum = page ? parseInt(page, 10) : 1;
    const pageSizeNum = pageSize ? parseInt(pageSize, 10) : 10;
    return this.adminService.getPostList(pageNum, pageSizeNum);
  }

  @Delete('posts/:id')
  async deletePost(
    @Headers('x-admin-token') adminToken: string,
    @Param('id') id: string,
  ): Promise<void> {
    this.checkAdmin(adminToken);
    return this.adminService.deletePost(id);
  }

  @Put('posts/:id/top')
  async setTop(
    @Headers('x-admin-token') adminToken: string,
    @Param('id') id: string,
    @Body() body: { isTop: boolean },
  ): Promise<void> {
    this.checkAdmin(adminToken);
    if (typeof body.isTop !== 'boolean') {
      throw new BadRequestException('isTop 必须为布尔值');
    }
    return this.adminService.toggleTop(id, body.isTop);
  }

  @Get('comments')
  async getCommentList(
    @Headers('x-admin-token') adminToken: string,
    @Query('page') page?: string,
    @Query('pageSize') pageSize?: string,
  ): Promise<AdminCommentListResponse> {
    this.checkAdmin(adminToken);
    const pageNum = page ? parseInt(page, 10) : 1;
    const pageSizeNum = pageSize ? parseInt(pageSize, 10) : 10;
    return this.adminService.getCommentList(pageNum, pageSizeNum);
  }

  @Delete('comments/:id')
  async deleteComment(
    @Headers('x-admin-token') adminToken: string,
    @Param('id') id: string,
  ): Promise<void> {
    this.checkAdmin(adminToken);
    return this.adminService.deleteComment(id);
  }

  @Get('sensitive-words')
  async getSensitiveWordList(
    @Headers('x-admin-token') adminToken: string,
    @Query('page') page?: string,
    @Query('pageSize') pageSize?: string,
  ): Promise<SensitiveWordListResponse> {
    this.checkAdmin(adminToken);
    const pageNum = page ? parseInt(page, 10) : 1;
    const pageSizeNum = pageSize ? parseInt(pageSize, 10) : 10;
    return this.adminService.getSensitiveWordList(pageNum, pageSizeNum);
  }

  @Post('sensitive-words')
  async addSensitiveWord(
    @Headers('x-admin-token') adminToken: string,
    @Body() body: { word: string },
  ): Promise<SensitiveWord> {
    this.checkAdmin(adminToken);
    return this.adminService.addSensitiveWord(body.word);
  }

  @Delete('sensitive-words/:id')
  async deleteSensitiveWord(
    @Headers('x-admin-token') adminToken: string,
    @Param('id') id: string,
  ): Promise<void> {
    this.checkAdmin(adminToken);
    return this.adminService.deleteSensitiveWord(id);
  }

  @Get('users')
  async getUserList(
    @Headers('x-admin-token') adminToken: string,
    @Query('page') page?: string,
    @Query('pageSize') pageSize?: string,
  ): Promise<ForumUserListResponse> {
    this.checkAdmin(adminToken);
    const pageNum = page ? parseInt(page, 10) : 1;
    const pageSizeNum = pageSize ? parseInt(pageSize, 10) : 10;
    return this.adminService.getUserList(pageNum, pageSizeNum);
  }

  @Post('users')
  async createUser(
    @Headers('x-admin-token') adminToken: string,
    @Body() dto: CreateUserRequest,
  ): Promise<ForumUser> {
    this.checkAdmin(adminToken);
    return this.adminService.createUser(dto);
  }

  @Delete('users/:id')
  async deleteUser(
    @Headers('x-admin-token') adminToken: string,
    @Param('id') id: string,
  ): Promise<void> {
    this.checkAdmin(adminToken);
    return this.adminService.deleteUser(id);
  }

  @Put('users/:id/password')
  async resetPassword(
    @Headers('x-admin-token') adminToken: string,
    @Param('id') id: string,
    @Body() dto: ResetPasswordRequest,
  ): Promise<void> {
    this.checkAdmin(adminToken);
    return this.adminService.resetPassword(id, dto.password);
  }
}
