import {
  Inject,
  Injectable,
  Logger,
  NotFoundException,
  BadRequestException,
} from '@nestjs/common';
import { DRIZZLE_DATABASE, type PostgresJsDatabase } from '@server/database/drizzle.module';
import { eq, and, count, desc, sql, ilike, or, asc } from 'drizzle-orm';
import { posts, likes, comments, sensitiveWords } from '@server/database/schema';
import type {
  Post,
  PostCategory,
  PostListResponse,
  CategoryCount,
  CreatePostRequest,
  ContactInfo,
  Comment,
  CommentListResponse,
  CreateCommentRequest,
  LikeStatus,
} from '@shared/api.interface';

interface PostRow {
  id: string;
  title: string;
  content: string;
  category: string;
  contactInfo: unknown;
  authorUserId: string;
  authorNickname: string;
  isTop: boolean;
  createdAt: Date;
  updatedAt: Date;
  likeCount: number | string;
  commentCount: number | string;
  isLiked: boolean | null;
}

interface CommentRow {
  id: string;
  postId: string;
  userId: string;
  nickname: string;
  content: string;
  createdAt: Date;
}

const UUID_REGEX = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;

function validateUuid(id: string, label: string): void {
  if (!UUID_REGEX.test(id)) {
    throw new BadRequestException(`无效的${label}ID格式`);
  }
}

@Injectable()
export class ForumService {
  private readonly logger = new Logger(ForumService.name);

  constructor(@Inject(DRIZZLE_DATABASE) private readonly db: PostgresJsDatabase) {}

  private toPost(row: PostRow): Post {
    return {
      id: row.id,
      title: row.title,
      content: row.content,
      category: row.category as PostCategory,
      contactInfo: row.contactInfo as ContactInfo | null,
      authorUserId: row.authorUserId,
      authorNickname: row.authorNickname,
      isTop: Boolean(row.isTop),
      createdAt: row.createdAt.toISOString(),
      updatedAt: row.updatedAt.toISOString(),
      likeCount: Number(row.likeCount),
      commentCount: Number(row.commentCount),
      isLiked: Boolean(row.isLiked),
    };
  }

  private toComment(row: CommentRow): Comment {
    return {
      id: row.id,
      postId: row.postId,
      userId: row.userId,
      nickname: row.nickname,
      content: row.content,
      createdAt: row.createdAt.toISOString(),
    };
  }

  async checkSensitiveContent(text: string): Promise<boolean> {
    const rows = await this.db.select({ word: sensitiveWords.word }).from(sensitiveWords);
    for (const row of rows) {
      if (text.includes(row.word)) {
        return true;
      }
    }
    return false;
  }

  private async validateSensitiveContent(title: string, content: string): Promise<void> {
    const combined = `${title}\n${content}`;
    const hasSensitive = await this.checkSensitiveContent(combined);
    if (hasSensitive) {
      throw new BadRequestException('内容包含违规词，请修改后发表');
    }
  }

  private buildPostSelect(currentUserId: string | null) {
    const likeCountSubquery = sql<number>`(
      SELECT count(*) FROM ${likes} WHERE ${likes.postId} = ${posts.id}
    )`;
    const commentCountSubquery = sql<number>`(
      SELECT count(*) FROM ${comments} WHERE ${comments.postId} = ${posts.id}
    )`;
    const isLikedSubquery = currentUserId
      ? sql<boolean>`(
          SELECT EXISTS (
            SELECT 1 FROM ${likes}
            WHERE ${likes.postId} = ${posts.id}
              AND ${likes.userId} = ${currentUserId}
          )
        )`
      : sql<boolean>`false`;

    return {
      id: posts.id,
      title: posts.title,
      content: posts.content,
      category: posts.category,
      contactInfo: posts.contactInfo,
      authorUserId: posts.authorUserId,
      authorNickname: posts.authorNickname,
      isTop: posts.isTop,
      createdAt: posts.createdAt,
      updatedAt: posts.updatedAt,
      likeCount: likeCountSubquery,
      commentCount: commentCountSubquery,
      isLiked: isLikedSubquery,
    };
  }

  async getList(
    page: number,
    pageSize: number,
    category?: string,
    keyword?: string,
    currentUserId?: string | null,
  ): Promise<PostListResponse> {
    const pageNum = Math.max(1, page);
    const pageSizeNum = Math.max(1, Math.min(50, pageSize));
    const offset = (pageNum - 1) * pageSizeNum;

    const conditions = [];
    if (category && category !== 'all') {
      conditions.push(eq(posts.category, category));
    }
    if (keyword && keyword.trim()) {
      const kw = `%${keyword.trim()}%`;
      conditions.push(or(
        ilike(posts.title, kw),
        ilike(posts.content, kw),
        ilike(posts.authorNickname, kw),
      ));
    }

    const whereClause = conditions.length > 0 ? and(...conditions) : undefined;
    const selectCols = this.buildPostSelect(currentUserId ?? null);

    const [rows, countResult] = await Promise.all([
      this.db
        .select(selectCols)
        .from(posts)
        .where(whereClause)
        .orderBy(desc(posts.isTop), desc(posts.createdAt))
        .limit(pageSizeNum)
        .offset(offset),
      this.db
        .select({ count: count() })
        .from(posts)
        .where(whereClause),
    ]);

    const total = Number(countResult[0]?.count ?? 0);
    const items: Post[] = rows.map((row: PostRow) => this.toPost(row));

    return {
      items,
      total,
      page: pageNum,
      pageSize: pageSizeNum,
    };
  }

  async getCategoryCounts(): Promise<{ counts: CategoryCount[] }> {
    const rows: { category: string; count: string | number }[] = await this.db
      .select({
        category: posts.category,
        count: count(),
      })
      .from(posts)
      .groupBy(posts.category);

    const counts: CategoryCount[] = rows.map((row: { category: string; count: string | number }) => ({
      category: row.category as PostCategory,
      count: Number(row.count),
    }));

    return { counts };
  }

  async getById(id: string, currentUserId?: string | null): Promise<Post> {
    validateUuid(id, '帖子');

    const selectCols = this.buildPostSelect(currentUserId ?? null);
    const rows = await this.db
      .select(selectCols)
      .from(posts)
      .where(eq(posts.id, id))
      .limit(1);

    if (rows.length === 0) {
      throw new NotFoundException('帖子不存在');
    }
    return this.toPost(rows[0] as PostRow);
  }

  async create(dto: CreatePostRequest, userId: string, nickname: string): Promise<Post> {
    if (!dto.title || !dto.title.trim()) {
      throw new BadRequestException('标题不能为空');
    }
    if (!dto.content || !dto.content.trim()) {
      throw new BadRequestException('内容不能为空');
    }
    if (!dto.category) {
      throw new BadRequestException('分区不能为空');
    }

    await this.validateSensitiveContent(dto.title.trim(), dto.content.trim());

    const now = new Date();
    const inserted = await this.db
      .insert(posts)
      .values({
        title: dto.title.trim(),
        content: dto.content.trim(),
        category: dto.category,
        contactInfo: dto.contactInfo ?? null,
        authorUserId: userId,
        authorNickname: nickname,
        createdAt: now,
        updatedAt: now,
      })
      .returning();

    if (inserted.length === 0) {
      throw new BadRequestException('创建帖子失败');
    }

    return this.getById(inserted[0].id, userId);
  }

  async getMyList(
    userId: string,
    page: number,
    pageSize: number,
  ): Promise<PostListResponse> {
    const pageNum = Math.max(1, page);
    const pageSizeNum = Math.max(1, Math.min(50, pageSize));
    const offset = (pageNum - 1) * pageSizeNum;

    const selectCols = this.buildPostSelect(userId);

    const [rows, countResult] = await Promise.all([
      this.db
        .select(selectCols)
        .from(posts)
        .where(eq(posts.authorUserId, userId))
        .orderBy(desc(posts.createdAt))
        .limit(pageSizeNum)
        .offset(offset),
      this.db
        .select({ count: count() })
        .from(posts)
        .where(eq(posts.authorUserId, userId)),
    ]);

    const total = Number(countResult[0]?.count ?? 0);
    const items: Post[] = rows.map((row: PostRow) => this.toPost(row));

    return {
      items,
      total,
      page: pageNum,
      pageSize: pageSizeNum,
    };
  }

  async getComments(postId: string): Promise<CommentListResponse> {
    validateUuid(postId, '帖子');

    const postExists = await this.db
      .select({ id: posts.id })
      .from(posts)
      .where(eq(posts.id, postId))
      .limit(1);
    if (postExists.length === 0) {
      throw new NotFoundException('帖子不存在');
    }

    const [rows, countResult] = await Promise.all([
      this.db
        .select()
        .from(comments)
        .where(eq(comments.postId, postId))
        .orderBy(asc(comments.createdAt)),
      this.db
        .select({ count: count() })
        .from(comments)
        .where(eq(comments.postId, postId)),
    ]);

    const total = Number(countResult[0]?.count ?? 0);
    const items: Comment[] = rows.map((row: CommentRow) => this.toComment(row));

    return { items, total };
  }

  async createComment(
    postId: string,
    dto: CreateCommentRequest,
    userId: string,
    nickname: string,
  ): Promise<Comment> {
    validateUuid(postId, '帖子');

    if (!dto.content || !dto.content.trim()) {
      throw new BadRequestException('评论内容不能为空');
    }

    const postExists = await this.db
      .select({ id: posts.id })
      .from(posts)
      .where(eq(posts.id, postId))
      .limit(1);
    if (postExists.length === 0) {
      throw new NotFoundException('帖子不存在');
    }

    const hasSensitive = await this.checkSensitiveContent(dto.content.trim());
    if (hasSensitive) {
      throw new BadRequestException('内容包含违规词，请修改后发表');
    }

    const now = new Date();
    const inserted = await this.db
      .insert(comments)
      .values({
        postId,
        userId,
        nickname,
        content: dto.content.trim(),
        createdAt: now,
        updatedAt: now,
      })
      .returning();

    if (inserted.length === 0) {
      throw new BadRequestException('创建评论失败');
    }

    return this.toComment(inserted[0] as CommentRow);
  }

  async getLikeStatus(postId: string, userId: string | null): Promise<LikeStatus> {
    validateUuid(postId, '帖子');

    const postExists = await this.db
      .select({ id: posts.id })
      .from(posts)
      .where(eq(posts.id, postId))
      .limit(1);
    if (postExists.length === 0) {
      throw new NotFoundException('帖子不存在');
    }

    const [likeCountResult, userLikeResult] = await Promise.all([
      this.db
        .select({ count: count() })
        .from(likes)
        .where(eq(likes.postId, postId)),
      userId
        ? this.db
            .select({ id: likes.id })
            .from(likes)
            .where(and(eq(likes.postId, postId), eq(likes.userId, userId)))
            .limit(1)
        : Promise.resolve([]),
    ]);

    return {
      likeCount: Number(likeCountResult[0]?.count ?? 0),
      isLiked: userLikeResult.length > 0,
    };
  }

  async likePost(postId: string, userId: string): Promise<LikeStatus> {
    validateUuid(postId, '帖子');

    const postExists = await this.db
      .select({ id: posts.id })
      .from(posts)
      .where(eq(posts.id, postId))
      .limit(1);
    if (postExists.length === 0) {
      throw new NotFoundException('帖子不存在');
    }

    const existing = await this.db
      .select({ id: likes.id })
      .from(likes)
      .where(and(eq(likes.postId, postId), eq(likes.userId, userId)))
      .limit(1);

    if (existing.length > 0) {
      return this.getLikeStatus(postId, userId);
    }

    const now = new Date();
    try {
      await this.db.insert(likes).values({
        postId,
        userId,
        createdAt: now,
        updatedAt: now,
      });
    } catch (error: unknown) {
      const code = this.extractPostgresErrorCode(error);
      if (code === '23505') {
        this.logger.log(`重复点赞已幂等处理: postId=${postId}, userId=${userId}`);
        return this.getLikeStatus(postId, userId);
      }
      throw error;
    }

    return this.getLikeStatus(postId, userId);
  }

  async unlikePost(postId: string, userId: string): Promise<LikeStatus> {
    validateUuid(postId, '帖子');

    const postExists = await this.db
      .select({ id: posts.id })
      .from(posts)
      .where(eq(posts.id, postId))
      .limit(1);
    if (postExists.length === 0) {
      throw new NotFoundException('帖子不存在');
    }

    await this.db
      .delete(likes)
      .where(and(eq(likes.postId, postId), eq(likes.userId, userId)));

    return this.getLikeStatus(postId, userId);
  }

  private extractPostgresErrorCode(error: unknown): string | undefined {
    let current: unknown = error;
    for (let depth = 0; depth < 4 && current && typeof current === 'object'; depth += 1) {
      const { code, cause } = current as { code?: unknown; cause?: unknown };
      if (typeof code === 'string') return code;
      current = cause;
    }
    return undefined;
  }
}
