import {
  Controller,
  Get,
  Post,
  Delete,
  Body,
  Param,
  Query,
  UseGuards,
} from '@nestjs/common';
import { JwtAuthGuard } from '@server/common/guards/jwt-auth.guard';
import { OptionalJwtAuthGuard } from '@server/common/guards/optional-jwt-auth.guard';
import { CurrentUser } from '@server/common/decorators/current-user.decorator';
import { ForumService } from './forum.service';
import type {
  Post as PostEntity,
  PostListResponse,
  CategoryCount,
  CreatePostRequest,
  Comment,
  CommentListResponse,
  CreateCommentRequest,
  LikeStatus,
  CurrentUserInfo,
} from '@shared/api.interface';

@Controller('api/posts')
export class ForumController {
  constructor(private readonly forumService: ForumService) {}

  // ===== 读接口：可选登录（访客也能访问）=====

  @Get()
  @UseGuards(OptionalJwtAuthGuard)
  async getList(
    @CurrentUser() user: CurrentUserInfo | null,
    @Query('page') page?: string,
    @Query('pageSize') pageSize?: string,
    @Query('category') category?: string,
    @Query('keyword') keyword?: string,
  ): Promise<PostListResponse> {
    const pageNum = page ? parseInt(page, 10) : 1;
    const pageSizeNum = pageSize ? parseInt(pageSize, 10) : 10;
    return this.forumService.getList(pageNum, pageSizeNum, category, keyword, user?.userId ?? null);
  }

  @Get('category-counts')
  async getCategoryCounts(): Promise<{ counts: CategoryCount[] }> {
    return this.forumService.getCategoryCounts();
  }

  @Get(':id')
  @UseGuards(OptionalJwtAuthGuard)
  async getById(
    @CurrentUser() user: CurrentUserInfo | null,
    @Param('id') id: string,
  ): Promise<PostEntity> {
    return this.forumService.getById(id, user?.userId ?? null);
  }

  @Get(':id/comments')
  async getComments(@Param('id') id: string): Promise<CommentListResponse> {
    return this.forumService.getComments(id);
  }

  @Get(':id/like-status')
  @UseGuards(OptionalJwtAuthGuard)
  async getLikeStatus(
    @CurrentUser() user: CurrentUserInfo | null,
    @Param('id') id: string,
  ): Promise<LikeStatus> {
    return this.forumService.getLikeStatus(id, user?.userId ?? null);
  }

  // ===== 写接口：强制登录 =====

  @Get('mine/list')
  @UseGuards(JwtAuthGuard)
  async getMyList(
    @CurrentUser() user: CurrentUserInfo,
    @Query('page') page?: string,
    @Query('pageSize') pageSize?: string,
  ): Promise<PostListResponse> {
    const pageNum = page ? parseInt(page, 10) : 1;
    const pageSizeNum = pageSize ? parseInt(pageSize, 10) : 10;
    return this.forumService.getMyList(user.userId, pageNum, pageSizeNum);
  }

  @Post()
  @UseGuards(JwtAuthGuard)
  async create(
    @CurrentUser() user: CurrentUserInfo,
    @Body() dto: CreatePostRequest,
  ): Promise<PostEntity> {
    return this.forumService.create(dto, user.userId, user.nickname);
  }

  @Post(':id/comments')
  @UseGuards(JwtAuthGuard)
  async createComment(
    @CurrentUser() user: CurrentUserInfo,
    @Param('id') id: string,
    @Body() dto: CreateCommentRequest,
  ): Promise<Comment> {
    return this.forumService.createComment(id, dto, user.userId, user.nickname);
  }

  @Post(':id/like')
  @UseGuards(JwtAuthGuard)
  async likePost(
    @CurrentUser() user: CurrentUserInfo,
    @Param('id') id: string,
  ): Promise<LikeStatus> {
    return this.forumService.likePost(id, user.userId);
  }

  @Delete(':id/unlike')
  @UseGuards(JwtAuthGuard)
  async unlikePost(
    @CurrentUser() user: CurrentUserInfo,
    @Param('id') id: string,
  ): Promise<LikeStatus> {
    return this.forumService.unlikePost(id, user.userId);
  }
}
