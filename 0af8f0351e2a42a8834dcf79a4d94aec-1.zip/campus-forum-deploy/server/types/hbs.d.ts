declare module 'hbs' {
  import type { Request, Response } from 'express';
  export function __express(
    filePath: string,
    options: Record<string, unknown>,
    callback: (err: Error | null, rendered?: string) => void
  ): void;
  export function registerPartial(name: string, source: string): void;
  export function registerHelper(name: string, helper: (...args: unknown[]) => unknown): void;
  export function locals(app: unknown): void;
  const _default: {
    __express: typeof __express;
    registerPartial: typeof registerPartial;
    registerHelper: typeof registerHelper;
  };
  export default _default;
}
