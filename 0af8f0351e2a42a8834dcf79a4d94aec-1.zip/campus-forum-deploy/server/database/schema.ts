import { sql } from 'drizzle-orm';
import {
  boolean,
  foreignKey,
  index,
  jsonb,
  pgTable,
  text,
  uniqueIndex,
  uuid,
  varchar,
  customType,
} from 'drizzle-orm/pg-core';

export const customTimestamptz = customType<{
  data: Date;
  driverData: string;
  config: { precision?: number };
}>({
  dataType(config) {
    const precision = typeof config?.precision !== 'undefined'
      ? ` (${config.precision})`
      : '';
    return `timestamptz${precision}`;
  },
  toDriver(value: Date | string | number) {
    if (value == null) return value as unknown as string;
    if (typeof value === 'number') return new Date(value).toISOString();
    if (typeof value === 'string') return value;
    if (value instanceof Date) return value.toISOString();
    throw new Error('Invalid timestamp value');
  },
  fromDriver(value: string | Date): Date {
    if (value instanceof Date) return value;
    return new Date(value);
  },
});

export const forumUsers = pgTable('forum_users', {
  id: uuid('id').primaryKey().defaultRandom(),
  username: varchar('username', { length: 50 }).notNull().unique(),
  nickname: varchar('nickname', { length: 100 }).notNull(),
  password: varchar('password', { length: 255 }).notNull(),
  createdAt: customTimestamptz('_created_at', { precision: 3 }).notNull().default(sql`CURRENT_TIMESTAMP`),
  updatedAt: customTimestamptz('_updated_at', { precision: 3 }).notNull().default(sql`CURRENT_TIMESTAMP`),
}, (table) => [
  uniqueIndex('forum_users_username_key').on(table.username),
  index('idx_forum_users_username').on(table.username),
]);

export const posts = pgTable('posts', {
  id: uuid('id').primaryKey().defaultRandom(),
  title: varchar('title', { length: 200 }).notNull(),
  content: text('content').notNull(),
  category: varchar('category', { length: 50 }).notNull(),
  contactInfo: jsonb('contact_info'),
  authorUserId: varchar('author_user_id', { length: 255 }).notNull(),
  authorNickname: varchar('author_nickname', { length: 100 }).notNull(),
  isTop: boolean('is_top').notNull().default(false),
  createdAt: customTimestamptz('_created_at', { precision: 3 }).notNull().default(sql`CURRENT_TIMESTAMP`),
  updatedAt: customTimestamptz('_updated_at', { precision: 3 }).notNull().default(sql`CURRENT_TIMESTAMP`),
}, (table) => [
  index('idx_posts_category').on(table.category),
  index('idx_posts_created_at').on(table.createdAt),
  index('idx_posts_author_user_id').on(table.authorUserId),
  index('idx_posts_is_top').on(table.isTop),
]);

export const comments = pgTable('comments', {
  id: uuid('id').primaryKey().defaultRandom(),
  postId: uuid('post_id').notNull(),
  userId: varchar('user_id', { length: 255 }).notNull(),
  nickname: varchar('nickname', { length: 100 }).notNull(),
  content: text('content').notNull(),
  createdAt: customTimestamptz('_created_at', { precision: 3 }).notNull().default(sql`CURRENT_TIMESTAMP`),
  updatedAt: customTimestamptz('_updated_at', { precision: 3 }).notNull().default(sql`CURRENT_TIMESTAMP`),
}, (table) => [
  index('idx_comments_post_id').on(table.postId),
  index('idx_comments_created_at').on(table.createdAt),
  index('idx_comments_user_id').on(table.userId),
  foreignKey({
    columns: [table.postId],
    foreignColumns: [posts.id],
    name: 'comments_post_id_fkey',
  }).onDelete('cascade'),
]);

export const likes = pgTable('likes', {
  id: uuid('id').primaryKey().defaultRandom(),
  postId: uuid('post_id').notNull(),
  userId: varchar('user_id', { length: 255 }).notNull(),
  createdAt: customTimestamptz('_created_at', { precision: 3 }).notNull().default(sql`CURRENT_TIMESTAMP`),
  updatedAt: customTimestamptz('_updated_at', { precision: 3 }).notNull().default(sql`CURRENT_TIMESTAMP`),
}, (table) => [
  uniqueIndex('idx_likes_post_user').on(table.postId, table.userId),
  index('idx_likes_post_id').on(table.postId),
  index('idx_likes_user_id').on(table.userId),
  foreignKey({
    columns: [table.postId],
    foreignColumns: [posts.id],
    name: 'likes_post_id_fkey',
  }).onDelete('cascade'),
]);

export const sensitiveWords = pgTable('sensitive_words', {
  id: uuid('id').primaryKey().defaultRandom(),
  word: varchar('word', { length: 100 }).notNull().unique(),
  createdAt: customTimestamptz('_created_at', { precision: 3 }).notNull().default(sql`CURRENT_TIMESTAMP`),
  updatedAt: customTimestamptz('_updated_at', { precision: 3 }).notNull().default(sql`CURRENT_TIMESTAMP`),
}, (table) => [
  uniqueIndex('sensitive_words_word_key').on(table.word),
]);
