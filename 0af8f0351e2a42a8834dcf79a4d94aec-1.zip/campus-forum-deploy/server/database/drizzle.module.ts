import { Module, Global } from '@nestjs/common';
import { drizzle } from 'drizzle-orm/postgres-js';
import postgres from 'postgres';

export const DRIZZLE_DATABASE = 'DRIZZLE_DATABASE';
export type PostgresJsDatabase = ReturnType<typeof drizzle>;

@Global()
@Module({
  providers: [
    {
      provide: DRIZZLE_DATABASE,
      useFactory: () => {
        const databaseUrl = process.env.DATABASE_URL || 'postgresql://postgres:postgres@localhost:5432/campus_forum';
        const queryClient = postgres(databaseUrl);
        const db = drizzle(queryClient);
        return db;
      },
    },
  ],
  exports: [DRIZZLE_DATABASE],
})
export class DrizzleModule {}
