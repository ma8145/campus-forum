import React, { createContext, useContext, useState, useEffect, useCallback } from 'react';
import { adminLogin, getAdminToken, clearAdminToken } from '@/api/admin';

interface AdminAuthContextType {
  adminToken: string | null;
  login: (username: string, password: string) => Promise<void>;
  clearAdminAuth: () => void;
}

const AdminAuthContext = createContext<AdminAuthContextType | undefined>(undefined);

export const AdminAuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [adminToken, setAdminToken] = useState<string | null>(null);

  useEffect(() => {
    const token = getAdminToken();
    if (token) {
      setAdminToken(token);
    }
  }, []);

  const login = useCallback(async (username: string, password: string): Promise<void> => {
    const result = await adminLogin({ username, password });
    setAdminToken(result.token);
  }, []);

  const clearAdminAuth = useCallback((): void => {
    clearAdminToken();
    setAdminToken(null);
  }, []);

  const value: AdminAuthContextType = {
    adminToken,
    login,
    clearAdminAuth,
  };

  return (
    <AdminAuthContext.Provider value={value}>{children}</AdminAuthContext.Provider>
  );
};

export function useAdminAuth(): AdminAuthContextType {
  const context = useContext(AdminAuthContext);
  if (!context) {
    throw new Error('useAdminAuth must be used within an AdminAuthProvider');
  }
  return context;
}
