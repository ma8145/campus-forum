import React, { createContext, useContext, useState, useEffect, useCallback } from 'react';
import type { AuthUser, LoginRequest } from '@shared/api.interface';
import { login as apiLogin, logout as apiLogout, getCurrentUser, getToken, getStoredUser } from '@/api/auth';

const GUEST_KEY = 'forum_guest_mode';

interface AuthContextType {
  user: AuthUser | null;
  isLoggedIn: boolean;
  isGuest: boolean;
  loading: boolean;
  login: (username: string, password: string) => Promise<void>;
  loginAsGuest: () => void;
  logout: () => void;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<AuthUser | null>(null);
  const [loading, setLoading] = useState<boolean>(true);
  const [isGuest, setIsGuest] = useState<boolean>(false);

  useEffect(() => {
    const token = getToken();
    const guestFlag = localStorage.getItem(GUEST_KEY) === '1';

    if (token) {
      if (guestFlag) localStorage.removeItem(GUEST_KEY);
      const stored = getStoredUser();
      if (stored) setUser(stored);
      getCurrentUser()
        .then((u: AuthUser) => {
          setUser(u);
          localStorage.setItem('forum_user', JSON.stringify(u));
        })
        .catch(() => {
          apiLogout();
          setUser(null);
        })
        .finally(() => setLoading(false));
    } else {
      if (guestFlag) setIsGuest(true);
      setLoading(false);
    }
  }, []);

  const login = useCallback(async (username: string, password: string): Promise<void> => {
    const params: LoginRequest = { username, password };
    const result = await apiLogin(params);
    localStorage.removeItem(GUEST_KEY);
    setIsGuest(false);
    setUser(result.user);
  }, []);

  const loginAsGuest = useCallback((): void => {
    apiLogout();
    setUser(null);
    localStorage.setItem(GUEST_KEY, '1');
    setIsGuest(true);
  }, []);

  const logout = useCallback((): void => {
    apiLogout();
    setUser(null);
    if (localStorage.getItem(GUEST_KEY) === '1') {
      localStorage.removeItem(GUEST_KEY);
    }
    setIsGuest(false);
  }, []);

  const value: AuthContextType = {
    user,
    isLoggedIn: !!user && !!getToken(),
    isGuest,
    loading,
    login,
    loginAsGuest,
    logout,
  };

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
};

export function useAuth(): AuthContextType {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
}
