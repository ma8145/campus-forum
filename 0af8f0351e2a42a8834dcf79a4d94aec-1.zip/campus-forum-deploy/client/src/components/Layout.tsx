import React, { useState, useEffect } from 'react';
import { Outlet, useLocation } from 'react-router-dom';
import Header from './Header';
import Sidebar from './Sidebar';
import MobileDrawer from './MobileDrawer';
import { getCategoryCounts } from '@/api/forum';

const Layout: React.FC = () => {
  const location = useLocation();
  const [drawerOpen, setDrawerOpen] = useState<boolean>(false);
  const [categoryCounts, setCategoryCounts] = useState<Record<string, number>>({});

  const isDetailPage = location.pathname.startsWith('/post/');
  const isCreatePage = location.pathname === '/create';
  const isProfilePage = location.pathname === '/profile';
  const showSidebar = !isDetailPage && !isCreatePage && !isProfilePage;

  useEffect(() => {
    getCategoryCounts()
      .then((res) => {
        const counts: Record<string, number> = {};
        res.counts.forEach((c) => {
          counts[c.category] = c.count;
        });
        setCategoryCounts(counts);
      })
      .catch(() => {
        // 静默失败
      });
  }, [location.pathname]);

  return (
    <div className="flex min-h-screen flex-col bg-background">
      <Header onMenuClick={() => setDrawerOpen(true)} />
      <div className="flex flex-1">
        {showSidebar && <Sidebar />}
        <main className="flex-1 overflow-x-hidden p-4 md:p-6">
          <div className="max-w-4xl mx-auto">
            <Outlet />
          </div>
        </main>
      </div>
      <MobileDrawer
        open={drawerOpen}
        onClose={() => setDrawerOpen(false)}
        categoryCounts={categoryCounts}
      />
    </div>
  );
};

export default Layout;
