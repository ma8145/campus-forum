import React from 'react';
import dayjs from 'dayjs';
import relativeTime from 'dayjs/plugin/relativeTime';
import 'dayjs/locale/zh-cn';
import { Heart, MessageCircle, Pin } from 'lucide-react';

import type { Post } from '@shared/api.interface';
import { POST_CATEGORIES, type PostCategory } from '@shared/api.interface';

dayjs.extend(relativeTime);
dayjs.locale('zh-cn');

const categoryBadgeClassMap: Record<string, string> = {
  delivery: 'bg-blue-100 text-blue-700',
  charge: 'bg-amber-100 text-amber-700',
  market: 'bg-green-100 text-green-700',
  lostfound: 'bg-purple-100 text-purple-700',
  chat: 'bg-pink-100 text-pink-700',
  expose: 'bg-red-100 text-red-700',
  findpeople: 'bg-indigo-100 text-indigo-700',
  love: 'bg-rose-100 text-rose-700',
};

const getCategoryName = (key: PostCategory): string => {
  const found = POST_CATEGORIES.find((c: { key: PostCategory | 'all'; name: string }) => c.key === key);
  return found ? found.name : key;
};

const getCategoryBadgeClass = (key: string): string => {
  return categoryBadgeClassMap[key] || 'bg-gray-100 text-gray-700';
};

interface PostCardProps {
  post: Post;
  onClick?: () => void;
}

const PostCard: React.FC<PostCardProps> = ({ post, onClick }) => {
  const colorClass = getCategoryBadgeClass(post.category);

  return (
    <article
      className="cursor-pointer rounded-lg border border-border bg-white p-4 transition-shadow hover:shadow-md"
      onClick={onClick}
    >
      <div className="mb-2 flex items-center gap-2">
        {post.isTop && (
          <span className="inline-flex items-center gap-1 rounded-full bg-red-500 px-2 py-0.5 text-xs font-medium text-white">
            <Pin className="size-3" />
            置顶
          </span>
        )}
        <span className={`rounded-full px-2.5 py-0.5 text-xs font-medium ${colorClass}`}>
          {getCategoryName(post.category)}
        </span>
      </div>

      <h3 className="mb-2 line-clamp-1 text-base font-semibold text-foreground">
        {post.title}
      </h3>

      <p className="mb-3 line-clamp-2 text-sm text-muted-foreground">
        {post.content}
      </p>

      <div className="flex items-center justify-between text-xs text-muted-foreground">
        <div className="flex items-center gap-3">
          <span>{post.authorNickname}</span>
          <span>·</span>
          <span>{dayjs(post.createdAt).fromNow()}</span>
        </div>
        <div className="flex items-center gap-4">
          <div className="flex items-center gap-1">
            <Heart className="size-3.5" />
            <span>{post.likeCount}</span>
          </div>
          <div className="flex items-center gap-1">
            <MessageCircle className="size-3.5" />
            <span>{post.commentCount}</span>
          </div>
        </div>
      </div>
    </article>
  );
};

export default PostCard;
