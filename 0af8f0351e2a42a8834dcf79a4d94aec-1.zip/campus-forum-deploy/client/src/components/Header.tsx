import React, { useState } from 'react';
import { useNavigate, useSearchParams } from 'react-router-dom';
import { Search, PenSquare, User, LogOut, Menu, UserRound, LogIn } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import { Avatar, AvatarFallback } from '@/components/ui/avatar';
import { useAuth } from '@/hooks/useAuth';

interface HeaderProps {
  onMenuClick?: () => void;
}

const Header: React.FC<HeaderProps> = ({ onMenuClick }) => {
  const navigate = useNavigate();
  const [searchParams, setSearchParams] = useSearchParams();
  const { user, isLoggedIn, isGuest, logout } = useAuth();
  const [searchValue, setSearchValue] = useState<string>(searchParams.get('keyword') ?? '');

  const handleSearch = (e: React.FormEvent<HTMLFormElement>): void => {
    e.preventDefault();
    const keyword = searchValue.trim();
    if (keyword) {
      setSearchParams({ keyword });
      navigate('/');
    }
  };

  const handlePostClick = (): void => {
    if (!isLoggedIn) {
      if (isGuest) {
        toastGuestWarning('发帖');
      }
      navigate('/login');
      return;
    }
    navigate('/create');
  };

  const handleProfileClick = (): void => {
    navigate('/profile');
  };

  const handleLogout = (): void => {
    logout();
    navigate('/login');
  };

  const displayName: string = user?.nickname || '用户';
  const initial: string = displayName.charAt(0).toUpperCase();

  return (
    <header className="sticky top-0 z-50 border-b border-border bg-white/80 backdrop-blur-sm">
      <div className="flex h-16 items-center justify-between px-4 md:px-6">
        {/* 左侧：汉堡按钮 + Logo */}
        <div className="flex items-center gap-2">
          {onMenuClick && (
            <Button
              variant="ghost"
              size="icon"
              className="lg:hidden"
              onClick={onMenuClick}
              aria-label="打开菜单"
            >
              <Menu className="size-5" />
            </Button>
          )}
          <div
            className="flex cursor-pointer items-center gap-2"
            onClick={() => navigate('/')}
          >
            <div className="flex size-9 items-center justify-center rounded-lg bg-primary font-bold text-primary-foreground">
              校
            </div>
            <div className="hidden sm:block">
              <div className="text-base font-bold text-foreground">工商行政管理学院</div>
              <div className="text-xs text-muted-foreground">校园社区</div>
            </div>
          </div>
        </div>

        {/* 中间：搜索（桌面端） */}
        <div className="flex-1 max-w-md mx-4 hidden md:block">
          <form onSubmit={handleSearch}>
            <div className="relative">
              <Search className="absolute left-3 top-1/2 size-4 -translate-y-1/2 text-muted-foreground" />
              <Input
                type="text"
                placeholder="搜索帖子..."
                className="pl-9"
                value={searchValue}
                onChange={(e: React.ChangeEvent<HTMLInputElement>) =>
                  setSearchValue(e.target.value)
                }
              />
            </div>
          </form>
        </div>

        {/* 右侧：操作按钮 */}
        <div className="flex items-center gap-2">
          <Button onClick={handlePostClick} className="gap-1">
            <PenSquare className="size-4" />
            <span className="hidden md:inline">发帖</span>
          </Button>

          {isLoggedIn ? (
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="ghost" size="icon" className="size-9 rounded-full">
                  <Avatar className="size-8">
                    <AvatarFallback>{initial}</AvatarFallback>
                  </Avatar>
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end" className="w-48">
                <DropdownMenuLabel className="font-normal">
                  <div className="text-sm font-medium text-foreground">{displayName}</div>
                  <div className="text-xs text-muted-foreground">{user?.username}</div>
                </DropdownMenuLabel>
                <DropdownMenuSeparator />
                <DropdownMenuItem onClick={handleProfileClick}>
                  <User className="mr-2 size-4" />
                  个人中心
                </DropdownMenuItem>
                <DropdownMenuSeparator />
                <DropdownMenuItem onClick={handleLogout} className="text-destructive">
                  <LogOut className="mr-2 size-4" />
                  退出登录
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          ) : isGuest ? (
            <Button variant="outline" size="sm" onClick={() => navigate('/login')}>
              <UserRound className="mr-1 size-3" />
              <span className="hidden sm:inline">访客·</span>登录
            </Button>
          ) : (
            <Button variant="outline" onClick={() => navigate('/login')}>
              登录
            </Button>
          )}
        </div>
      </div>

      {/* 移动端搜索栏 */}
      <div className="px-4 pb-3 md:hidden">
        <form onSubmit={handleSearch}>
          <div className="relative">
            <Search className="absolute left-3 top-1/2 size-4 -translate-y-1/2 text-muted-foreground" />
            <Input
              type="text"
              placeholder="搜索帖子..."
              className="pl-9"
              value={searchValue}
              onChange={(e: React.ChangeEvent<HTMLInputElement>) => setSearchValue(e.target.value)}
            />
          </div>
        </form>
      </div>
    </header>
  );
};

function toastGuestWarning(action: string): void {
  // 简单的 alert 替代，实际项目用 sonner toast
  if (typeof window !== 'undefined') {
    // 延迟执行，避免和导航冲突
    setTimeout(() => {
      alert(`请登录后${action}`);
    }, 100);
  }
}

export default Header;
