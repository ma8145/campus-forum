import React from 'react';
import { useNavigate, useSearchParams } from 'react-router-dom';
import { X, LogOut, UserRound, LogIn } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Avatar, AvatarFallback } from '@/components/ui/avatar';
import { useAuth } from '@/hooks/useAuth';
import { POST_CATEGORIES } from '@shared/api.interface';

interface MobileDrawerProps {
  open: boolean;
  onClose: () => void;
  categoryCounts: Record<string, number>;
}

const MobileDrawer: React.FC<MobileDrawerProps> = ({ open, onClose, categoryCounts }) => {
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  const { user, isLoggedIn, isGuest, logout } = useAuth();

  const currentCategory = searchParams.get('category') ?? 'all';

  const handleCategoryClick = (categoryKey: string): void => {
    if (categoryKey === 'all') {
      navigate('/');
    } else {
      navigate(`/?category=${categoryKey}`);
    }
    onClose();
  };

  const handleLogout = (): void => {
    logout();
    onClose();
    navigate('/login');
  };

  const displayName = user?.nickname || '用户';
  const initial = displayName.charAt(0).toUpperCase();

  if (!open) return null;

  return (
    <div className="fixed inset-0 z-[100] lg:hidden">
      {/* 遮罩 */}
      <div
        className="absolute inset-0 bg-black/50"
        onClick={onClose}
      />
      {/* 抽屉 */}
      <div className="absolute left-0 top-0 h-full w-72 bg-white shadow-xl flex flex-col">
        {/* 头部 */}
        <div className="flex items-center justify-between border-b p-4">
          <div className="flex items-center gap-2">
            <div className="flex size-8 items-center justify-center rounded-lg bg-primary font-bold text-primary-foreground text-sm">
              校
            </div>
            <span className="font-bold">工商校园论坛</span>
          </div>
          <Button variant="ghost" size="icon" onClick={onClose}>
            <X className="size-5" />
          </Button>
        </div>

        {/* 分区列表 */}
        <div className="flex-1 overflow-y-auto p-2">
          <div className="px-2 py-1 text-xs font-medium text-muted-foreground">分区</div>
          <button
            type="button"
            onClick={() => handleCategoryClick('all')}
            className={`flex w-full items-center justify-between rounded-lg px-3 py-2.5 text-sm transition-colors ${
              currentCategory === 'all'
                ? 'bg-primary/10 font-medium text-primary'
                : 'hover:bg-muted'
            }`}
          >
            <span>全部</span>
          </button>
          {POST_CATEGORIES.map((cat) => (
            <button
              key={cat.key}
              type="button"
              onClick={() => handleCategoryClick(cat.key)}
              className={`flex w-full items-center justify-between rounded-lg px-3 py-2.5 text-sm transition-colors ${
                currentCategory === cat.key
                  ? 'bg-primary/10 font-medium text-primary'
                  : 'hover:bg-muted'
              }`}
            >
              <span>{cat.name}</span>
              {categoryCounts[cat.key] !== undefined && categoryCounts[cat.key] > 0 && (
                <span className="rounded-full bg-muted px-2 py-0.5 text-xs text-muted-foreground">
                  {categoryCounts[cat.key]}
                </span>
              )}
            </button>
          ))}
        </div>

        {/* 底部用户信息 */}
        <div className="border-t p-4">
          {isLoggedIn && user ? (
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <Avatar className="size-9">
                  <AvatarFallback>{initial}</AvatarFallback>
                </Avatar>
                <div>
                  <div className="text-sm font-medium">{displayName}</div>
                  <div className="text-xs text-muted-foreground">{user.username}</div>
                </div>
              </div>
              <Button variant="ghost" size="icon" onClick={handleLogout}>
                <LogOut className="size-4" />
              </Button>
            </div>
          ) : isGuest ? (
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="flex size-9 items-center justify-center rounded-full bg-muted">
                  <UserRound className="size-5 text-muted-foreground" />
                </div>
                <div>
                  <div className="text-sm font-medium">访客</div>
                  <div className="text-xs text-muted-foreground">浏览模式</div>
                </div>
              </div>
              <Button
                variant="outline"
                size="sm"
                onClick={() => {
                  onClose();
                  navigate('/login');
                }}
              >
                <LogIn className="mr-1 size-3" />
                登录
              </Button>
            </div>
          ) : (
            <Button
              className="w-full"
              onClick={() => {
                onClose();
                navigate('/login');
              }}
            >
              登录
            </Button>
          )}
        </div>
      </div>
    </div>
  );
};

export default MobileDrawer;
