import React, { useEffect, useState } from 'react';
import { useSearchParams } from 'react-router-dom';
import {
  Package,
  Zap,
  ShoppingBag,
  Search,
  MessageCircle,
  AlertOctagon,
  Users,
  Heart,
  Grid3X3,
} from 'lucide-react';
import { getCategoryCounts } from '@/api/forum';
import { POST_CATEGORIES, type PostCategory } from '@shared/api.interface';

const categoryIconMap: Record<string, React.ReactNode> = {
  all: <Grid3X3 className="size-4" />,
  delivery: <Package className="size-4" />,
  charge: <Zap className="size-4" />,
  market: <ShoppingBag className="size-4" />,
  lostfound: <Search className="size-4" />,
  chat: <MessageCircle className="size-4" />,
  expose: <AlertOctagon className="size-4" />,
  findpeople: <Users className="size-4" />,
  love: <Heart className="size-4" />,
};

const categoryColorMap: Record<string, string> = {
  all: 'text-gray-600',
  delivery: 'text-blue-600',
  charge: 'text-amber-600',
  market: 'text-green-600',
  lostfound: 'text-purple-600',
  chat: 'text-pink-600',
  expose: 'text-red-600',
  findpeople: 'text-indigo-600',
  love: 'text-rose-600',
};

const Sidebar: React.FC = () => {
  const [searchParams, setSearchParams] = useSearchParams();
  const activeCategory: string = searchParams.get('category') ?? 'all';
  const [counts, setCounts] = useState<Record<string, number>>({});
  const [totalCount, setTotalCount] = useState<number>(0);
  const [loading, setLoading] = useState<boolean>(true);

  useEffect(() => {
    const fetchCounts = async (): Promise<void> => {
      try {
        const result = await getCategoryCounts();
        const countMap: Record<string, number> = {};
        let total = 0;
        for (const item of result.counts) {
          countMap[item.category] = item.count;
          total += item.count;
        }
        setCounts(countMap);
        setTotalCount(total);
      } catch (error: unknown) {
        console.error('Sidebar fetchCategoryCounts failed', error);
      } finally {
        setLoading(false);
      }
    };
    void fetchCounts();
  }, []);

  const handleCategoryClick = (key: string): void => {
    const keyword = searchParams.get('keyword');
    const params: Record<string, string> = {};
    if (key !== 'all') params.category = key;
    if (keyword) params.keyword = keyword;
    setSearchParams(params);
  };

  return (
    <aside className="hidden w-56 shrink-0 border-r border-border bg-sidebar p-4 lg:block">
      <nav className="space-y-1">
        {POST_CATEGORIES.map((cat: { key: PostCategory | 'all'; name: string }) => {
          const isActive: boolean = activeCategory === cat.key;
          const iconColor: string = categoryColorMap[cat.key] ?? 'text-gray-600';
          const countValue: number = cat.key === 'all' ? totalCount : counts[cat.key] ?? 0;
          return (
            <button
              key={cat.key}
              type="button"
              onClick={() => handleCategoryClick(cat.key)}
              className={`flex w-full items-center justify-between rounded-lg px-3 py-2 text-sm font-medium transition-colors ${
                isActive
                  ? 'bg-primary text-primary-foreground'
                  : 'text-foreground hover:bg-primary/10'
              }`}
            >
              <div className="flex items-center gap-2">
                <span className={isActive ? 'text-primary-foreground' : iconColor}>
                  {categoryIconMap[cat.key]}
                </span>
                <span>{cat.name}</span>
              </div>
              {!loading && (
                <span
                  className={`rounded-full px-2 py-0.5 text-xs ${
                    isActive
                      ? 'bg-white/20 text-primary-foreground'
                      : 'bg-muted text-muted-foreground'
                  }`}
                >
                  {countValue}
                </span>
              )}
            </button>
          );
        })}
      </nav>
    </aside>
  );
};

export default Sidebar;
