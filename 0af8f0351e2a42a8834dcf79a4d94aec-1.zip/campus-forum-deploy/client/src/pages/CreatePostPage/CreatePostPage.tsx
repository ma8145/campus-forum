import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { toast } from 'sonner';
import { ArrowLeft, Loader2, Send, LogIn } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { createPost } from '@/api/forum';
import { useAuth } from '@/hooks/useAuth';
import { POST_CATEGORIES, type PostCategory, type ContactInfo } from '@shared/api.interface';

const CreatePostPage: React.FC = () => {
  const navigate = useNavigate();
  const { isLoggedIn, isGuest } = useAuth();
  const [title, setTitle] = useState<string>('');
  const [content, setContent] = useState<string>('');
  const [category, setCategory] = useState<string>('');
  const [qq, setQq] = useState<string>('');
  const [wechat, setWechat] = useState<string>('');
  const [phone, setPhone] = useState<string>('');
  const [submitting, setSubmitting] = useState<boolean>(false);

  const handleSubmit = async (e: React.FormEvent<HTMLFormElement>): Promise<void> => {
    e.preventDefault();
    if (!isLoggedIn) {
      if (isGuest) toast.error('请登录后发帖');
      navigate('/login');
      return;
    }
    if (!category) {
      toast.error('请选择分区');
      return;
    }
    if (!title.trim()) {
      toast.error('请输入标题');
      return;
    }
    if (!content.trim()) {
      toast.error('请输入内容');
      return;
    }
    if (!qq.trim() && !wechat.trim() && !phone.trim()) {
      toast.error('请至少填写一种联系方式');
      return;
    }
    const contactInfo: ContactInfo = {};
    if (qq.trim()) contactInfo.qq = qq.trim();
    if (wechat.trim()) contactInfo.wechat = wechat.trim();
    if (phone.trim()) contactInfo.phone = phone.trim();
    setSubmitting(true);
    try {
      const post = await createPost({
        title: title.trim(),
        content: content.trim(),
        category: category as PostCategory,
        contactInfo,
      });
      toast.success('发布成功');
      navigate(`/post/${post.id}`);
    } catch (error: unknown) {
      const message =
        (error as { response?: { data?: { error?: { message?: string } } } })?.response?.data?.error
          ?.message || '发布失败';
      toast.error(message);
    } finally {
      setSubmitting(false);
    }
  };

  if (isGuest) {
    return (
      <div className="mx-auto max-w-2xl space-y-4">
        <Button variant="ghost" size="sm" className="gap-1" onClick={() => navigate(-1)}>
          <ArrowLeft className="size-4" />
          返回
        </Button>
        <Card>
          <CardContent className="flex flex-col items-center justify-center py-16">
            <div className="mb-4 flex size-16 items-center justify-center rounded-full bg-muted">
              <LogIn className="size-8 text-muted-foreground" />
            </div>
            <h2 className="mb-2 text-lg font-semibold">需要登录</h2>
            <p className="mb-6 text-sm text-muted-foreground">访客模式下无法发帖，请登录后继续</p>
            <Button onClick={() => navigate('/login')}>
              <LogIn className="mr-2 size-4" />
              去登录
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="mx-auto max-w-2xl space-y-4">
      <Button variant="ghost" size="sm" className="gap-1" onClick={() => navigate(-1)}>
        <ArrowLeft className="size-4" />
        返回
      </Button>
      <Card>
        <CardHeader>
          <CardTitle>发布新帖</CardTitle>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleSubmit} className="space-y-5">
            <div className="space-y-2">
              <Label htmlFor="category">分区 *</Label>
              <Select value={category} onValueChange={setCategory}>
                <SelectTrigger id="category">
                  <SelectValue placeholder="请选择分区" />
                </SelectTrigger>
                <SelectContent>
                  {POST_CATEGORIES.filter(
                    (c: { key: PostCategory | 'all'; name: string }) => c.key !== 'all',
                  ).map((cat: { key: PostCategory | 'all'; name: string; description: string }) => (
                    <SelectItem key={cat.key} value={cat.key}>
                      {cat.name} — {cat.description}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label htmlFor="title">标题 *</Label>
              <Input
                id="title"
                placeholder="请输入帖子标题"
                value={title}
                onChange={(e: React.ChangeEvent<HTMLInputElement>) => setTitle(e.target.value)}
                maxLength={100}
              />
              <div className="text-right text-xs text-muted-foreground">{title.length}/100</div>
            </div>
            <div className="space-y-2">
              <Label htmlFor="content">内容 *</Label>
              <Textarea
                id="content"
                placeholder="请输入帖子内容..."
                value={content}
                onChange={(e: React.ChangeEvent<HTMLTextAreaElement>) => setContent(e.target.value)}
                className="min-h-40 resize-y"
                maxLength={2000}
              />
              <div className="text-right text-xs text-muted-foreground">{content.length}/2000</div>
            </div>
            <div className="space-y-3 rounded-lg border border-border p-4">
              <Label>联系方式（至少填写一种）*</Label>
              <div className="grid grid-cols-1 gap-3 md:grid-cols-3">
                <div className="space-y-1">
                  <Label htmlFor="qq" className="text-xs text-muted-foreground">
                    QQ
                  </Label>
                  <Input
                    id="qq"
                    placeholder="QQ号"
                    value={qq}
                    onChange={(e: React.ChangeEvent<HTMLInputElement>) => setQq(e.target.value)}
                  />
                </div>
                <div className="space-y-1">
                  <Label htmlFor="wechat" className="text-xs text-muted-foreground">
                    微信
                  </Label>
                  <Input
                    id="wechat"
                    placeholder="微信号"
                    value={wechat}
                    onChange={(e: React.ChangeEvent<HTMLInputElement>) => setWechat(e.target.value)}
                  />
                </div>
                <div className="space-y-1">
                  <Label htmlFor="phone" className="text-xs text-muted-foreground">
                    电话
                  </Label>
                  <Input
                    id="phone"
                    placeholder="手机号"
                    value={phone}
                    onChange={(e: React.ChangeEvent<HTMLInputElement>) => setPhone(e.target.value)}
                  />
                </div>
              </div>
            </div>
            <div className="flex justify-end gap-2">
              <Button type="button" variant="outline" onClick={() => navigate(-1)}>
                取消
              </Button>
              <Button type="submit" disabled={submitting} className="gap-1">
                {submitting ? (
                  <>
                    <Loader2 className="size-4 animate-spin" />
                    发布中...
                  </>
                ) : (
                  <>
                    <Send className="size-4" />
                    发布
                  </>
                )}
              </Button>
            </div>
          </form>
        </CardContent>
      </Card>
    </div>
  );
};

export default CreatePostPage;
