import React, { useEffect, useState, useCallback } from 'react';
import { useNavigate } from 'react-router-dom';
import { toast } from 'sonner';
import { Loader2, Inbox, User as UserIcon, LogOut } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Avatar, AvatarFallback } from '@/components/ui/avatar';
import { Separator } from '@/components/ui/separator';
import PostCard from '@/components/PostCard';
import { getMyPosts } from '@/api/forum';
import { useAuth } from '@/hooks/useAuth';
import type { Post } from '@shared/api.interface';

const ProfilePage: React.FC = () => {
  const navigate = useNavigate();
  const { user, logout } = useAuth();
  const [posts, setPosts] = useState<Post[]>([]);
  const [loading, setLoading] = useState<boolean>(true);

  const fetchMyPosts = useCallback(async (): Promise<void> => {
    setLoading(true);
    try {
      const result = await getMyPosts({ page: 1, pageSize: 50 });
      setPosts(result.items);
    } catch (error: unknown) {
      toast.error('加载失败');
      console.error('ProfilePage fetchMyPosts failed', error);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    void fetchMyPosts();
  }, [fetchMyPosts]);

  const handleLogout = (): void => {
    logout();
    navigate('/login');
  };

  const handlePostClick = (postId: string): void => {
    navigate(`/post/${postId}`);
  };

  if (!user) {
    return null;
  }

  return (
    <div className="mx-auto max-w-3xl space-y-4">
      <Card>
        <CardContent className="p-6">
          <div className="flex items-start justify-between">
            <div className="flex items-center gap-4">
              <Avatar className="size-16">
                <AvatarFallback className="text-xl">{user.nickname.charAt(0)}</AvatarFallback>
              </Avatar>
              <div>
                <h2 className="text-xl font-bold text-foreground">{user.nickname}</h2>
                <p className="text-sm text-muted-foreground">@{user.username}</p>
              </div>
            </div>
            <Button variant="outline" size="sm" className="gap-1" onClick={handleLogout}>
              <LogOut className="size-4" />
              退出登录
            </Button>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader className="pb-3">
          <CardTitle className="flex items-center gap-2 text-lg">
            <UserIcon className="size-5" />
            我的帖子 ({posts.length})
          </CardTitle>
        </CardHeader>
        <Separator />
        <CardContent className="pt-4">
          {loading ? (
            <div className="flex items-center justify-center py-12">
              <Loader2 className="size-6 animate-spin text-primary" />
            </div>
          ) : posts.length === 0 ? (
            <div className="flex flex-col items-center justify-center py-12 text-center">
              <Inbox className="mb-3 size-10 text-muted-foreground" />
              <p className="mb-1 text-base font-medium text-foreground">还没有发布过帖子</p>
              <p className="mb-4 text-sm text-muted-foreground">快去发布第一条帖子吧</p>
              <Button onClick={() => navigate('/create')}>发布帖子</Button>
            </div>
          ) : (
            <div className="space-y-3">
              {posts.map((post: Post) => (
                <PostCard
                  key={post.id}
                  post={post}
                  onClick={() => handlePostClick(post.id)}
                />
              ))}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
};

export default ProfilePage;
