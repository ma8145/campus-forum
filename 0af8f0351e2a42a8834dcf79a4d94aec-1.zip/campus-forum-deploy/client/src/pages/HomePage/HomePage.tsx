import React, { useEffect, useState, useCallback } from 'react';
import { useNavigate, useSearchParams } from 'react-router-dom';
import { toast } from 'sonner';
import { Loader2, Inbox, Plus } from 'lucide-react';
import { Button } from '@/components/ui/button';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import PostCard from '@/components/PostCard';
import { getPosts } from '@/api/forum';
import { POST_CATEGORIES, type Post, type PostCategory } from '@shared/api.interface';

const PAGE_SIZE = 10;

const HomePage: React.FC = () => {
  const navigate = useNavigate();
  const [searchParams, setSearchParams] = useSearchParams();
  const keyword = searchParams.get('keyword') ?? '';
  const categoryFromQuery = searchParams.get('category') ?? 'all';
  const [posts, setPosts] = useState<Post[]>([]);
  const [loading, setLoading] = useState<boolean>(true);
  const [page, setPage] = useState<number>(1);
  const [total, setTotal] = useState<number>(0);
  const [hasMore, setHasMore] = useState<boolean>(false);

  const activeCategory: string = categoryFromQuery;

  const fetchPosts = useCallback(
    async (pageNum: number, reset: boolean = false): Promise<void> => {
      setLoading(true);
      try {
        const result = await getPosts({
          page: pageNum,
          pageSize: PAGE_SIZE,
          category: activeCategory === 'all' ? undefined : activeCategory,
          keyword: keyword || undefined,
        });
        setPosts((prev: Post[]) => (reset ? result.items : [...prev, ...result.items]));
        setTotal(result.total);
        setHasMore(result.page * result.pageSize < result.total);
      } catch (error: unknown) {
        toast.error('加载帖子失败');
        console.error('HomePage fetchPosts failed', error);
      } finally {
        setLoading(false);
      }
    },
    [activeCategory, keyword],
  );

  useEffect(() => {
    setPage(1);
    void fetchPosts(1, true);
  }, [fetchPosts]);

  const handleLoadMore = (): void => {
    const nextPage = page + 1;
    setPage(nextPage);
    void fetchPosts(nextPage, false);
  };

  const handleCategoryChange = (value: string): void => {
    const params: Record<string, string> = {};
    if (value !== 'all') params.category = value;
    if (keyword) params.keyword = keyword;
    setSearchParams(params);
  };

  const handlePostClick = (postId: string): void => {
    navigate(`/post/${postId}`);
  };

  const currentCategoryName: string =
    POST_CATEGORIES.find(
      (c: { key: PostCategory | 'all'; name: string }) => c.key === activeCategory,
    )?.name ?? '全部';

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h1 className="text-xl font-bold text-foreground">
          {keyword ? `搜索: ${keyword}` : currentCategoryName}
        </h1>
        <div className="flex items-center gap-2">
          <Select value={activeCategory} onValueChange={handleCategoryChange}>
            <SelectTrigger className="w-32 md:w-40">
              <SelectValue placeholder="选择分区" />
            </SelectTrigger>
            <SelectContent>
              {POST_CATEGORIES.map(
                (cat: { key: PostCategory | 'all'; name: string }) => (
                  <SelectItem key={cat.key} value={cat.key}>
                    {cat.name}
                  </SelectItem>
                ),
              )}
            </SelectContent>
          </Select>
          <Button onClick={() => navigate('/create')} size="sm" className="gap-1">
            <Plus className="size-4" />
            <span className="hidden md:inline">发帖</span>
          </Button>
        </div>
      </div>

      {loading && posts.length === 0 ? (
        <div className="flex items-center justify-center py-16">
          <Loader2 className="size-8 animate-spin text-primary" />
        </div>
      ) : posts.length === 0 ? (
        <div className="flex flex-col items-center justify-center py-16 text-center">
          <Inbox className="mb-3 size-12 text-muted-foreground" />
          <p className="mb-1 text-lg font-medium text-foreground">暂无帖子</p>
          <p className="mb-4 text-sm text-muted-foreground">
            {keyword ? '没有找到相关帖子' : '快来发布第一条帖子吧'}
          </p>
          {!keyword && (
            <Button onClick={() => navigate('/create')}>发布帖子</Button>
          )}
        </div>
      ) : (
        <>
          <div className="space-y-3">
            {posts.map((post: Post) => (
              <PostCard
                key={post.id}
                post={post}
                onClick={() => handlePostClick(post.id)}
              />
            ))}
          </div>
          {hasMore && (
            <div className="flex justify-center pt-4">
              <Button variant="outline" onClick={handleLoadMore} disabled={loading}>
                {loading ? (
                  <>
                    <Loader2 className="mr-2 size-4 animate-spin" />
                    加载中...
                  </>
                ) : (
                  '加载更多'
                )}
              </Button>
            </div>
          )}
          <div className="pt-2 text-center text-xs text-muted-foreground">
            共 {total} 条帖子
          </div>
        </>
      )}
    </div>
  );
};

export default HomePage;
