import React, { useEffect, useState, useCallback } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { toast } from 'sonner';
import dayjs from 'dayjs';
import relativeTime from 'dayjs/plugin/relativeTime';
import 'dayjs/locale/zh-cn';
import {
  ArrowLeft,
  Heart,
  MessageCircle,
  Send,
  Loader2,
  Phone,
  MessageSquare,
  Pin,
  LogIn,
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Avatar, AvatarFallback } from '@/components/ui/avatar';
import { Separator } from '@/components/ui/separator';
import {
  getPost,
  getComments,
  createComment,
  toggleLike,
  getLikeStatus,
} from '@/api/forum';
import { useAuth } from '@/hooks/useAuth';
import {
  POST_CATEGORIES,
  type Post,
  type Comment,
  type LikeStatus,
  type PostCategory,
} from '@shared/api.interface';

dayjs.extend(relativeTime);
dayjs.locale('zh-cn');

const categoryBadgeClassMap: Record<string, string> = {
  delivery: 'bg-blue-100 text-blue-700',
  charge: 'bg-amber-100 text-amber-700',
  market: 'bg-green-100 text-green-700',
  lostfound: 'bg-purple-100 text-purple-700',
  chat: 'bg-pink-100 text-pink-700',
  expose: 'bg-red-100 text-red-700',
  findpeople: 'bg-indigo-100 text-indigo-700',
  love: 'bg-rose-100 text-rose-700',
};

const getCategoryName = (key: PostCategory): string => {
  const found = POST_CATEGORIES.find((c: { key: PostCategory | 'all'; name: string }) => c.key === key);
  return found ? found.name : key;
};

const getCategoryBadgeClass = (key: string): string => {
  return categoryBadgeClassMap[key] || 'bg-gray-100 text-gray-700';
};

const PostDetailPage: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const { isLoggedIn, isGuest } = useAuth();
  const [post, setPost] = useState<Post | null>(null);
  const [comments, setComments] = useState<Comment[]>([]);
  const [likeStatus, setLikeStatus] = useState<LikeStatus>({ isLiked: false, likeCount: 0 });
  const [commentText, setCommentText] = useState<string>('');
  const [loading, setLoading] = useState<boolean>(true);
  const [submittingComment, setSubmittingComment] = useState<boolean>(false);
  const [liking, setLiking] = useState<boolean>(false);

  const fetchData = useCallback(async (): Promise<void> => {
    if (!id) return;
    setLoading(true);
    try {
      const [postData, commentsData, likeData] = await Promise.all([
        getPost(id),
        getComments(id),
        getLikeStatus(id),
      ]);
      setPost(postData);
      setComments(commentsData.items);
      setLikeStatus(likeData);
    } catch (error: unknown) {
      toast.error('加载帖子失败');
      console.error('PostDetailPage fetchData failed', error);
    } finally {
      setLoading(false);
    }
  }, [id]);

  useEffect(() => {
    void fetchData();
  }, [fetchData]);

  const handleLike = async (): Promise<void> => {
    if (!id) return;
    if (!isLoggedIn) {
      if (isGuest) toast.error('请登录后点赞');
      navigate('/login');
      return;
    }
    if (liking) return;

    const prevIsLiked = likeStatus.isLiked;
    const prevLikeCount = likeStatus.likeCount;

    // 乐观更新
    setLikeStatus({
      isLiked: !prevIsLiked,
      likeCount: prevIsLiked ? Math.max(0, prevLikeCount - 1) : prevLikeCount + 1,
    });
    setLiking(true);

    try {
      // 传目标状态：当前未点赞则点赞(true)，当前已点赞则取消(false)
      const result = await toggleLike(id, !prevIsLiked);
      setLikeStatus(result);
      setPost((prev: Post | null) =>
        prev ? { ...prev, likeCount: result.likeCount, isLiked: result.isLiked } : null,
      );
    } catch (error: unknown) {
      // 回滚
      setLikeStatus({ isLiked: prevIsLiked, likeCount: prevLikeCount });
      toast.error('操作失败');
    } finally {
      setLiking(false);
    }
  };

  const handleSubmitComment = async (e: React.FormEvent<HTMLFormElement>): Promise<void> => {
    e.preventDefault();
    if (!id || !commentText.trim()) return;
    if (!isLoggedIn) {
      if (isGuest) toast.error('请登录后评论');
      navigate('/login');
      return;
    }
    setSubmittingComment(true);
    try {
      const newComment = await createComment(id, commentText.trim());
      setComments((prev: Comment[]) => [...prev, newComment]);
      setCommentText('');
      toast.success('评论成功');
    } catch (error: unknown) {
      const message =
        (error as { response?: { data?: { error?: { message?: string } } } })?.response?.data?.error
          ?.message || '评论失败';
      toast.error(message);
    } finally {
      setSubmittingComment(false);
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center py-16">
        <Loader2 className="size-8 animate-spin text-primary" />
      </div>
    );
  }

  if (!post) {
    return (
      <div className="py-16 text-center">
        <p className="mb-4 text-lg text-muted-foreground">帖子不存在或已被删除</p>
        <Button onClick={() => navigate('/')}>返回首页</Button>
      </div>
    );
  }

  return (
    <div className="space-y-4">
      <Button variant="ghost" size="sm" className="gap-1" onClick={() => navigate(-1)}>
        <ArrowLeft className="size-4" />
        返回
      </Button>

      <Card>
        <CardContent className="p-6">
          <div className="mb-3 flex flex-wrap items-center gap-2">
            {post.isTop && (
              <Badge variant="destructive" className="gap-1">
                <Pin className="size-3" />
                置顶
              </Badge>
            )}
            <span className={`rounded-full px-2.5 py-0.5 text-xs font-medium ${getCategoryBadgeClass(post.category)}`}>
              {getCategoryName(post.category)}
            </span>
          </div>
          <h1 className="mb-3 text-2xl font-bold text-foreground">{post.title}</h1>
          <div className="mb-4 flex items-center gap-3 text-sm text-muted-foreground">
            <div className="flex items-center gap-2">
              <Avatar className="size-6">
                <AvatarFallback className="text-xs">{post.authorNickname.charAt(0)}</AvatarFallback>
              </Avatar>
              <span>{post.authorNickname}</span>
            </div>
            <span>·</span>
            <span>{dayjs(post.createdAt).format('YYYY-MM-DD HH:mm')}</span>
          </div>
          <Separator className="my-4" />
          <div className="mb-6 whitespace-pre-wrap text-base leading-relaxed text-foreground">
            {post.content}
          </div>
          {post.contactInfo && (
            <div className="mb-4 rounded-lg bg-muted p-4">
              <h3 className="mb-2 text-sm font-semibold text-foreground">联系方式</h3>
              <div className="space-y-1 text-sm text-muted-foreground">
                {post.contactInfo.qq && (
                  <div className="flex items-center gap-2">
                    <MessageSquare className="size-4" />
                    <span>QQ: {post.contactInfo.qq}</span>
                  </div>
                )}
                {post.contactInfo.wechat && (
                  <div className="flex items-center gap-2">
                    <MessageCircle className="size-4" />
                    <span>微信: {post.contactInfo.wechat}</span>
                  </div>
                )}
                {post.contactInfo.phone && (
                  <div className="flex items-center gap-2">
                    <Phone className="size-4" />
                    <span>电话: {post.contactInfo.phone}</span>
                  </div>
                )}
              </div>
            </div>
          )}
          <div className="flex items-center gap-4">
            <Button
              variant={likeStatus.isLiked ? 'default' : 'outline'}
              size="sm"
              className="gap-1"
              onClick={handleLike}
              disabled={liking}
            >
              <Heart className={`size-4 ${likeStatus.isLiked ? 'fill-current' : ''}`} />
              <span>{likeStatus.likeCount}</span>
            </Button>
            <div className="flex items-center gap-1 text-sm text-muted-foreground">
              <MessageCircle className="size-4" />
              <span>{comments.length} 条评论</span>
            </div>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardContent className="p-6">
          <h2 className="mb-4 text-lg font-semibold text-foreground">评论 ({comments.length})</h2>

          {isGuest ? (
            <div className="mb-6 rounded-lg border border-dashed p-6 text-center">
              <p className="mb-3 text-sm text-muted-foreground">请登录后发表评论</p>
              <Button size="sm" onClick={() => navigate('/login')}>
                <LogIn className="mr-1 size-3" />
                去登录
              </Button>
            </div>
          ) : (
            <form onSubmit={handleSubmitComment} className="mb-6 flex gap-2">
              <Textarea
                placeholder="发表你的评论..."
                value={commentText}
                onChange={(e: React.ChangeEvent<HTMLTextAreaElement>) => setCommentText(e.target.value)}
                className="min-h-20 resize-none"
                disabled={submittingComment}
              />
              <Button type="submit" size="icon" disabled={submittingComment || !commentText.trim()}>
                {submittingComment ? <Loader2 className="size-4 animate-spin" /> : <Send className="size-4" />}
              </Button>
            </form>
          )}

          {comments.length === 0 ? (
            <div className="py-8 text-center text-sm text-muted-foreground">
              暂无评论，快来抢沙发吧
            </div>
          ) : (
            <div className="space-y-4">
              {comments.map((comment: Comment) => (
                <div key={comment.id} className="flex gap-3">
                  <Avatar className="size-8 shrink-0">
                    <AvatarFallback className="text-xs">{comment.nickname.charAt(0)}</AvatarFallback>
                  </Avatar>
                  <div className="flex-1">
                    <div className="mb-1 flex items-center gap-2">
                      <span className="text-sm font-medium text-foreground">{comment.nickname}</span>
                      <span className="text-xs text-muted-foreground">
                        {dayjs(comment.createdAt).fromNow()}
                      </span>
                    </div>
                    <p className="text-sm text-foreground">{comment.content}</p>
                  </div>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
};

export default PostDetailPage;
