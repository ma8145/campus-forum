import React, { useEffect, useState, useCallback } from 'react';
import { toast } from 'sonner';
import dayjs from 'dayjs';
import { Loader2, Trash2, Plus, ShieldAlert } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from '@/components/ui/alert-dialog';
import { getSensitiveWords, addSensitiveWord, deleteSensitiveWord } from '@/api/admin';
import type { SensitiveWord } from '@shared/api.interface';

const SensitiveTab: React.FC = () => {
  const [words, setWords] = useState<SensitiveWord[]>([]);
  const [loading, setLoading] = useState<boolean>(true);
  const [newWord, setNewWord] = useState<string>('');
  const [adding, setAdding] = useState<boolean>(false);
  const [actionLoading, setActionLoading] = useState<string | null>(null);

  const fetchWords = useCallback(async (): Promise<void> => {
    setLoading(true);
    try {
      const result = await getSensitiveWords(1, 100);
      setWords(result.items);
    } catch (error: unknown) {
      toast.error('加载敏感词失败');
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    void fetchWords();
  }, [fetchWords]);

  const handleAdd = async (e: React.FormEvent<HTMLFormElement>): Promise<void> => {
    e.preventDefault();
    if (!newWord.trim()) {
      toast.error('请输入敏感词');
      return;
    }
    setAdding(true);
    try {
      const word = await addSensitiveWord(newWord.trim());
      toast.success('添加成功');
      setWords((prev: SensitiveWord[]) => [word, ...prev]);
      setNewWord('');
    } catch (error: unknown) {
      const message =
        (error as { response?: { data?: { error?: { message?: string } } } })?.response?.data?.error
          ?.message || '添加失败';
      toast.error(message);
    } finally {
      setAdding(false);
    }
  };

  const handleDelete = async (id: string): Promise<void> => {
    setActionLoading(id);
    try {
      await deleteSensitiveWord(id);
      toast.success('删除成功');
      setWords((prev: SensitiveWord[]) => prev.filter((w: SensitiveWord) => w.id !== id));
    } catch (error: unknown) {
      toast.error('删除失败');
    } finally {
      setActionLoading(null);
    }
  };

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h3 className="text-lg font-semibold">敏感词管理</h3>
        <span className="text-sm text-muted-foreground">共 {words.length} 个</span>
      </div>

      <div className="rounded-lg border border-amber-200 bg-amber-50 p-3 text-sm text-amber-800">
        <div className="flex items-center gap-2">
          <ShieldAlert className="size-4" />
          <span>用户发帖或评论时，如果内容包含以下敏感词，将被拦截并提示修改。</span>
        </div>
      </div>

      <form onSubmit={handleAdd} className="flex gap-2">
        <Input
          placeholder="输入新的敏感词..."
          value={newWord}
          onChange={(e: React.ChangeEvent<HTMLInputElement>) => setNewWord(e.target.value)}
          className="max-w-xs"
        />
        <Button type="submit" disabled={adding || !newWord.trim()} className="gap-1">
          {adding ? <Loader2 className="size-4 animate-spin" /> : <Plus className="size-4" />}
          添加
        </Button>
      </form>

      {loading ? (
        <div className="flex items-center justify-center py-12">
          <Loader2 className="size-6 animate-spin text-primary" />
        </div>
      ) : words.length === 0 ? (
        <div className="py-12 text-center text-sm text-muted-foreground">
          暂无敏感词
        </div>
      ) : (
        <div className="overflow-x-auto rounded-lg border">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>敏感词</TableHead>
                <TableHead className="w-32">添加时间</TableHead>
                <TableHead className="w-20 text-right">操作</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {words.map((word: SensitiveWord) => (
                <TableRow key={word.id}>
                  <TableCell>
                    <span className="font-medium text-destructive">{word.word}</span>
                  </TableCell>
                  <TableCell className="text-sm text-muted-foreground">
                    {dayjs(word.createdAt).format('YYYY-MM-DD')}
                  </TableCell>
                  <TableCell>
                    <div className="flex justify-end">
                      <AlertDialog>
                        <AlertDialogTrigger asChild>
                          <Button
                            variant="ghost"
                            size="icon"
                            className="size-8 text-destructive hover:text-destructive"
                            disabled={actionLoading === word.id}
                          >
                            <Trash2 className="size-4" />
                          </Button>
                        </AlertDialogTrigger>
                        <AlertDialogContent>
                          <AlertDialogHeader>
                            <AlertDialogTitle>确认删除</AlertDialogTitle>
                            <AlertDialogDescription>
                              确定要删除敏感词「{word.word}」吗？
                            </AlertDialogDescription>
                          </AlertDialogHeader>
                          <AlertDialogFooter>
                            <AlertDialogCancel>取消</AlertDialogCancel>
                            <AlertDialogAction
                              className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
                              onClick={() => handleDelete(word.id)}
                            >
                              删除
                            </AlertDialogAction>
                          </AlertDialogFooter>
                        </AlertDialogContent>
                      </AlertDialog>
                    </div>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </div>
      )}
    </div>
  );
};

export default SensitiveTab;
