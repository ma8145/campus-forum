import React, { useEffect, useState, useCallback } from 'react';
import { toast } from 'sonner';
import dayjs from 'dayjs';
import { Loader2, Trash2, UserPlus, KeyRound } from 'lucide-react';
import { Button } from '@/components/ui/button';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import { Badge } from '@/components/ui/badge';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from '@/components/ui/alert-dialog';
import { getAdminUsers, deleteAdminUser } from '@/api/admin';
import type { ForumUser } from '@shared/api.interface';
import AddUserDialog from './AddUserDialog';
import ResetPwdDialog from './ResetPwdDialog';

const PAGE_SIZE = 20;

const UsersTab: React.FC = () => {
  const [users, setUsers] = useState<ForumUser[]>([]);
  const [loading, setLoading] = useState<boolean>(true);
  const [page, setPage] = useState<number>(1);
  const [total, setTotal] = useState<number>(0);
  const [hasMore, setHasMore] = useState<boolean>(false);
  const [actionLoading, setActionLoading] = useState<string | null>(null);
  const [addDialogOpen, setAddDialogOpen] = useState<boolean>(false);
  const [resetUser, setResetUser] = useState<ForumUser | null>(null);

  const fetchUsers = useCallback(async (pageNum: number, reset: boolean = false): Promise<void> => {
    setLoading(true);
    try {
      const result = await getAdminUsers(pageNum, PAGE_SIZE);
      setUsers((prev: ForumUser[]) => (reset ? result.items : [...prev, ...result.items]));
      setTotal(result.total);
      setHasMore(result.page * result.pageSize < result.total);
    } catch (error: unknown) {
      toast.error('加载用户失败');
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    void fetchUsers(1, true);
  }, [fetchUsers]);

  const handleDelete = async (id: string): Promise<void> => {
    setActionLoading(id);
    try {
      await deleteAdminUser(id);
      toast.success('删除成功');
      setUsers((prev: ForumUser[]) => prev.filter((u: ForumUser) => u.id !== id));
      setTotal((prev: number) => prev - 1);
    } catch (error: unknown) {
      toast.error('删除失败');
    } finally {
      setActionLoading(null);
    }
  };

  const handleUserAdded = (user: ForumUser): void => {
    setUsers((prev: ForumUser[]) => [user, ...prev]);
    setTotal((prev: number) => prev + 1);
    setAddDialogOpen(false);
  };

  const handleLoadMore = (): void => {
    const nextPage = page + 1;
    setPage(nextPage);
    void fetchUsers(nextPage, false);
  };

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h3 className="text-lg font-semibold">用户列表</h3>
        <div className="flex items-center gap-2">
          <span className="text-sm text-muted-foreground">共 {total} 人</span>
          <Button size="sm" className="gap-1" onClick={() => setAddDialogOpen(true)}>
            <UserPlus className="size-4" />
            添加用户
          </Button>
        </div>
      </div>

      {loading && users.length === 0 ? (
        <div className="flex items-center justify-center py-12">
          <Loader2 className="size-6 animate-spin text-primary" />
        </div>
      ) : (
        <>
          <div className="overflow-x-auto rounded-lg border">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>用户名</TableHead>
                  <TableHead>昵称</TableHead>
                  <TableHead className="w-24">发帖数</TableHead>
                  <TableHead className="w-32">注册时间</TableHead>
                  <TableHead className="w-32 text-right">操作</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {users.map((user: ForumUser) => (
                  <TableRow key={user.id}>
                    <TableCell className="font-medium">{user.username}</TableCell>
                    <TableCell>{user.nickname}</TableCell>
                    <TableCell>
                      <Badge variant="secondary">{user.postCount}</Badge>
                    </TableCell>
                    <TableCell className="text-sm text-muted-foreground">
                      {dayjs(user.createdAt).format('YYYY-MM-DD')}
                    </TableCell>
                    <TableCell>
                      <div className="flex justify-end gap-1">
                        <Button
                          variant="ghost"
                          size="icon"
                          className="size-8"
                          onClick={() => setResetUser(user)}
                          disabled={actionLoading === user.id}
                          title="重置密码"
                        >
                          <KeyRound className="size-4" />
                        </Button>
                        <AlertDialog>
                          <AlertDialogTrigger asChild>
                            <Button
                              variant="ghost"
                              size="icon"
                              className="size-8 text-destructive hover:text-destructive"
                              disabled={actionLoading === user.id}
                            >
                              <Trash2 className="size-4" />
                            </Button>
                          </AlertDialogTrigger>
                          <AlertDialogContent>
                            <AlertDialogHeader>
                              <AlertDialogTitle>确认删除</AlertDialogTitle>
                              <AlertDialogDescription>
                                确定要删除用户「{user.username}」吗？该用户的所有帖子和评论也将被删除，此操作不可撤销。
                              </AlertDialogDescription>
                            </AlertDialogHeader>
                            <AlertDialogFooter>
                              <AlertDialogCancel>取消</AlertDialogCancel>
                              <AlertDialogAction
                                className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
                                onClick={() => handleDelete(user.id)}
                              >
                                删除
                              </AlertDialogAction>
                            </AlertDialogFooter>
                          </AlertDialogContent>
                        </AlertDialog>
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>

          {hasMore && (
            <div className="flex justify-center">
              <Button variant="outline" onClick={handleLoadMore} disabled={loading}>
                {loading ? (
                  <>
                    <Loader2 className="mr-2 size-4 animate-spin" />
                    加载中...
                  </>
                ) : (
                  '加载更多'
                )}
              </Button>
            </div>
          )}
        </>
      )}

      <AddUserDialog
        open={addDialogOpen}
        onOpenChange={setAddDialogOpen}
        onSuccess={handleUserAdded}
      />

      <ResetPwdDialog
        user={resetUser}
        open={!!resetUser}
        onOpenChange={(open: boolean) => !open && setResetUser(null)}
      />
    </div>
  );
};

export default UsersTab;
