import React, { useEffect, useState, useCallback } from 'react';
import { toast } from 'sonner';
import dayjs from 'dayjs';
import { Loader2, Trash2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from '@/components/ui/alert-dialog';
import { getAdminComments, deleteAdminComment } from '@/api/admin';
import type { Comment } from '@shared/api.interface';

const PAGE_SIZE = 20;

const CommentsTab: React.FC = () => {
  const [comments, setComments] = useState<Comment[]>([]);
  const [loading, setLoading] = useState<boolean>(true);
  const [page, setPage] = useState<number>(1);
  const [total, setTotal] = useState<number>(0);
  const [hasMore, setHasMore] = useState<boolean>(false);
  const [actionLoading, setActionLoading] = useState<string | null>(null);

  const fetchComments = useCallback(async (pageNum: number, reset: boolean = false): Promise<void> => {
    setLoading(true);
    try {
      const result = await getAdminComments(pageNum, PAGE_SIZE);
      setComments((prev: Comment[]) => (reset ? result.items : [...prev, ...result.items]));
      setTotal(result.total);
      setHasMore(result.page * result.pageSize < result.total);
    } catch (error: unknown) {
      toast.error('加载评论失败');
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    void fetchComments(1, true);
  }, [fetchComments]);

  const handleDelete = async (id: string): Promise<void> => {
    setActionLoading(id);
    try {
      await deleteAdminComment(id);
      toast.success('删除成功');
      setComments((prev: Comment[]) => prev.filter((c: Comment) => c.id !== id));
      setTotal((prev: number) => prev - 1);
    } catch (error: unknown) {
      toast.error('删除失败');
    } finally {
      setActionLoading(null);
    }
  };

  const handleLoadMore = (): void => {
    const nextPage = page + 1;
    setPage(nextPage);
    void fetchComments(nextPage, false);
  };

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h3 className="text-lg font-semibold">评论列表</h3>
        <span className="text-sm text-muted-foreground">共 {total} 条</span>
      </div>

      {loading && comments.length === 0 ? (
        <div className="flex items-center justify-center py-12">
          <Loader2 className="size-6 animate-spin text-primary" />
        </div>
      ) : (
        <>
          <div className="overflow-x-auto rounded-lg border">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>内容</TableHead>
                  <TableHead className="w-24">评论者</TableHead>
                  <TableHead className="w-32">评论时间</TableHead>
                  <TableHead className="w-20 text-right">操作</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {comments.map((comment: Comment) => (
                  <TableRow key={comment.id}>
                    <TableCell className="max-w-md">
                      <div className="truncate" title={comment.content}>
                        {comment.content}
                      </div>
                    </TableCell>
                    <TableCell className="text-sm">{comment.nickname}</TableCell>
                    <TableCell className="text-sm text-muted-foreground">
                      {dayjs(comment.createdAt).format('MM-DD HH:mm')}
                    </TableCell>
                    <TableCell>
                      <div className="flex justify-end">
                        <AlertDialog>
                          <AlertDialogTrigger asChild>
                            <Button
                              variant="ghost"
                              size="icon"
                              className="size-8 text-destructive hover:text-destructive"
                              disabled={actionLoading === comment.id}
                            >
                              <Trash2 className="size-4" />
                            </Button>
                          </AlertDialogTrigger>
                          <AlertDialogContent>
                            <AlertDialogHeader>
                              <AlertDialogTitle>确认删除</AlertDialogTitle>
                              <AlertDialogDescription>
                                确定要删除这条评论吗？此操作不可撤销。
                              </AlertDialogDescription>
                            </AlertDialogHeader>
                            <AlertDialogFooter>
                              <AlertDialogCancel>取消</AlertDialogCancel>
                              <AlertDialogAction
                                className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
                                onClick={() => handleDelete(comment.id)}
                              >
                                删除
                              </AlertDialogAction>
                            </AlertDialogFooter>
                          </AlertDialogContent>
                        </AlertDialog>
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>

          {hasMore && (
            <div className="flex justify-center">
              <Button variant="outline" onClick={handleLoadMore} disabled={loading}>
                {loading ? (
                  <>
                    <Loader2 className="mr-2 size-4 animate-spin" />
                    加载中...
                  </>
                ) : (
                  '加载更多'
                )}
              </Button>
            </div>
          )}
        </>
      )}
    </div>
  );
};

export default CommentsTab;
