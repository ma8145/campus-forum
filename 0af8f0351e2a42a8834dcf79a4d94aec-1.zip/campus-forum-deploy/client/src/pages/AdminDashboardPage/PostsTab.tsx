import React, { useEffect, useState, useCallback } from 'react';
import { toast } from 'sonner';
import dayjs from 'dayjs';
import { Loader2, Trash2, Pin, PinOff, Eye } from 'lucide-react';
import { Button } from '@/components/ui/button';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import { Badge } from '@/components/ui/badge';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from '@/components/ui/alert-dialog';
import { getAdminPosts, deleteAdminPost, setPostTop } from '@/api/admin';
import { POST_CATEGORIES, type Post, type PostCategory } from '@shared/api.interface';

const PAGE_SIZE = 10;

const getCategoryName = (key: PostCategory): string => {
  const found = POST_CATEGORIES.find((c: { key: PostCategory | 'all'; name: string }) => c.key === key);
  return found ? found.name : key;
};

const PostsTab: React.FC = () => {
  const [posts, setPosts] = useState<Post[]>([]);
  const [loading, setLoading] = useState<boolean>(true);
  const [page, setPage] = useState<number>(1);
  const [total, setTotal] = useState<number>(0);
  const [hasMore, setHasMore] = useState<boolean>(false);
  const [actionLoading, setActionLoading] = useState<string | null>(null);

  const fetchPosts = useCallback(async (pageNum: number, reset: boolean = false): Promise<void> => {
    setLoading(true);
    try {
      const result = await getAdminPosts(pageNum, PAGE_SIZE);
      setPosts((prev: Post[]) => (reset ? result.items : [...prev, ...result.items]));
      setTotal(result.total);
      setHasMore(result.page * result.pageSize < result.total);
    } catch (error: unknown) {
      toast.error('加载帖子失败');
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    void fetchPosts(1, true);
  }, [fetchPosts]);

  const handleDelete = async (id: string): Promise<void> => {
    setActionLoading(id);
    try {
      await deleteAdminPost(id);
      toast.success('删除成功');
      setPosts((prev: Post[]) => prev.filter((p: Post) => p.id !== id));
      setTotal((prev: number) => prev - 1);
    } catch (error: unknown) {
      toast.error('删除失败');
    } finally {
      setActionLoading(null);
    }
  };

  const handleToggleTop = async (post: Post): Promise<void> => {
    setActionLoading(post.id);
    try {
      await setPostTop(post.id, !post.isTop);
      toast.success(post.isTop ? '已取消置顶' : '已置顶');
      setPosts((prev: Post[]) =>
        prev.map((p: Post) => (p.id === post.id ? { ...p, isTop: !p.isTop } : p)),
      );
    } catch (error: unknown) {
      toast.error('操作失败');
    } finally {
      setActionLoading(null);
    }
  };

  const handleLoadMore = (): void => {
    const nextPage = page + 1;
    setPage(nextPage);
    void fetchPosts(nextPage, false);
  };

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h3 className="text-lg font-semibold">帖子列表</h3>
        <span className="text-sm text-muted-foreground">共 {total} 条</span>
      </div>

      {loading && posts.length === 0 ? (
        <div className="flex items-center justify-center py-12">
          <Loader2 className="size-6 animate-spin text-primary" />
        </div>
      ) : (
        <>
          <div className="overflow-x-auto rounded-lg border">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead className="w-12">置顶</TableHead>
                  <TableHead>标题</TableHead>
                  <TableHead className="w-24">分区</TableHead>
                  <TableHead className="w-24">作者</TableHead>
                  <TableHead className="w-32">发布时间</TableHead>
                  <TableHead className="w-32 text-right">操作</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {posts.map((post: Post) => (
                  <TableRow key={post.id}>
                    <TableCell>
                      {post.isTop ? (
                        <Badge variant="destructive" className="gap-1">
                          <Pin className="size-3" />
                          置顶
                        </Badge>
                      ) : (
                        <span className="text-muted-foreground">-</span>
                      )}
                    </TableCell>
                    <TableCell className="max-w-xs">
                      <div className="truncate font-medium" title={post.title}>
                        {post.title}
                      </div>
                    </TableCell>
                    <TableCell>
                      <Badge variant="secondary">{getCategoryName(post.category)}</Badge>
                    </TableCell>
                    <TableCell className="text-sm">{post.authorNickname}</TableCell>
                    <TableCell className="text-sm text-muted-foreground">
                      {dayjs(post.createdAt).format('MM-DD HH:mm')}
                    </TableCell>
                    <TableCell>
                      <div className="flex justify-end gap-1">
                        <Button
                          variant="ghost"
                          size="icon"
                          className="size-8"
                          onClick={() => handleToggleTop(post)}
                          disabled={actionLoading === post.id}
                          title={post.isTop ? '取消置顶' : '置顶'}
                        >
                          {post.isTop ? <PinOff className="size-4" /> : <Pin className="size-4" />}
                        </Button>
                        <AlertDialog>
                          <AlertDialogTrigger asChild>
                            <Button
                              variant="ghost"
                              size="icon"
                              className="size-8 text-destructive hover:text-destructive"
                              disabled={actionLoading === post.id}
                            >
                              <Trash2 className="size-4" />
                            </Button>
                          </AlertDialogTrigger>
                          <AlertDialogContent>
                            <AlertDialogHeader>
                              <AlertDialogTitle>确认删除</AlertDialogTitle>
                              <AlertDialogDescription>
                                确定要删除这篇帖子吗？此操作不可撤销。
                              </AlertDialogDescription>
                            </AlertDialogHeader>
                            <AlertDialogFooter>
                              <AlertDialogCancel>取消</AlertDialogCancel>
                              <AlertDialogAction
                                className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
                                onClick={() => handleDelete(post.id)}
                              >
                                删除
                              </AlertDialogAction>
                            </AlertDialogFooter>
                          </AlertDialogContent>
                        </AlertDialog>
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>

          {hasMore && (
            <div className="flex justify-center">
              <Button variant="outline" onClick={handleLoadMore} disabled={loading}>
                {loading ? (
                  <>
                    <Loader2 className="mr-2 size-4 animate-spin" />
                    加载中...
                  </>
                ) : (
                  '加载更多'
                )}
              </Button>
            </div>
          )}
        </>
      )}
    </div>
  );
};

export default PostsTab;
