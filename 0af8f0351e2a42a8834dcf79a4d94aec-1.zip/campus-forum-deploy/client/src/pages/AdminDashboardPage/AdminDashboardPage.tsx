import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { toast } from 'sonner';
import {
  LayoutDashboard,
  FileText,
  MessageSquare,
  ShieldAlert,
  Users,
  LogOut,
  Loader2,
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';
import PostsTab from './PostsTab';
import CommentsTab from './CommentsTab';
import SensitiveTab from './SensitiveTab';
import UsersTab from './UsersTab';
import { getAdminStats, logoutAdmin } from '@/api/admin';
import { useAdminAuth } from '@/hooks/useAdminAuth';
import type { AdminStats } from '@shared/api.interface';

const AdminDashboardPage: React.FC = () => {
  const navigate = useNavigate();
  const { clearAdminAuth } = useAdminAuth();
  const [stats, setStats] = useState<AdminStats | null>(null);
  const [loading, setLoading] = useState<boolean>(true);

  useEffect(() => {
    const fetchStats = async (): Promise<void> => {
      try {
        const data = await getAdminStats();
        setStats(data);
      } catch (error: unknown) {
        toast.error('加载统计数据失败');
      } finally {
        setLoading(false);
      }
    };
    void fetchStats();
  }, []);

  const handleLogout = async (): Promise<void> => {
    await logoutAdmin();
    clearAdminAuth();
    navigate('/admin/login');
  };

  return (
    <div className="min-h-screen bg-muted/30">
      <header className="sticky top-0 z-50 border-b border-border bg-white">
        <div className="flex h-16 items-center justify-between px-4 md:px-6">
          <div className="flex items-center gap-3">
            <div className="flex size-9 items-center justify-center rounded-lg bg-destructive text-destructive-foreground">
              <ShieldAlert className="size-5" />
            </div>
            <div>
              <div className="text-base font-bold">管理后台</div>
              <div className="text-xs text-muted-foreground">工商行政管理学院校园社区</div>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <Button variant="outline" size="sm" onClick={() => navigate('/')}>
              查看站点
            </Button>
            <Button variant="ghost" size="sm" className="gap-1 text-destructive" onClick={handleLogout}>
              <LogOut className="size-4" />
              退出
            </Button>
          </div>
        </div>
      </header>

      <div className="p-4 md:p-6">
        <div className="mx-auto max-w-6xl space-y-6">
          <div>
            <h1 className="text-2xl font-bold">控制台</h1>
            <p className="text-sm text-muted-foreground">管理校园社区的内容、用户和设置</p>
          </div>

          <div className="grid grid-cols-2 gap-4 md:grid-cols-4">
            {loading ? (
              <div className="col-span-full flex items-center justify-center py-8">
                <Loader2 className="size-6 animate-spin text-primary" />
              </div>
            ) : (
              <>
                <Card>
                  <CardContent className="p-4">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="text-sm text-muted-foreground">帖子总数</p>
                        <p className="text-2xl font-bold">{stats?.postCount ?? 0}</p>
                      </div>
                      <FileText className="size-8 text-blue-500" />
                    </div>
                  </CardContent>
                </Card>
                <Card>
                  <CardContent className="p-4">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="text-sm text-muted-foreground">评论总数</p>
                        <p className="text-2xl font-bold">{stats?.commentCount ?? 0}</p>
                      </div>
                      <MessageSquare className="size-8 text-green-500" />
                    </div>
                  </CardContent>
                </Card>
                <Card>
                  <CardContent className="p-4">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="text-sm text-muted-foreground">用户总数</p>
                        <p className="text-2xl font-bold">{stats?.userCount ?? 0}</p>
                      </div>
                      <Users className="size-8 text-purple-500" />
                    </div>
                  </CardContent>
                </Card>
                <Card>
                  <CardContent className="p-4">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="text-sm text-muted-foreground">敏感词</p>
                        <p className="text-2xl font-bold">{stats?.sensitiveWordCount ?? 0}</p>
                      </div>
                      <ShieldAlert className="size-8 text-red-500" />
                    </div>
                  </CardContent>
                </Card>
              </>
            )}
          </div>

          <Card>
            <CardContent className="p-0">
              <Tabs defaultValue="posts" className="w-full">
                <div className="border-b border-border px-4">
                  <TabsList className="h-14 w-full justify-start gap-1 bg-transparent">
                    <TabsTrigger
                      value="posts"
                      className="data-[state=active]:bg-transparent data-[state=active]:text-primary data-[state=active]:shadow-none h-14 rounded-none border-b-2 border-transparent px-4"
                    >
                      <FileText className="mr-2 size-4" />
                      帖子管理
                    </TabsTrigger>
                    <TabsTrigger
                      value="comments"
                      className="data-[state=active]:bg-transparent data-[state=active]:text-primary data-[state=active]:shadow-none h-14 rounded-none border-b-2 border-transparent px-4"
                    >
                      <MessageSquare className="mr-2 size-4" />
                      评论管理
                    </TabsTrigger>
                    <TabsTrigger
                      value="users"
                      className="data-[state=active]:bg-transparent data-[state=active]:text-primary data-[state=active]:shadow-none h-14 rounded-none border-b-2 border-transparent px-4"
                    >
                      <Users className="mr-2 size-4" />
                      用户管理
                    </TabsTrigger>
                    <TabsTrigger
                      value="sensitive"
                      className="data-[state=active]:bg-transparent data-[state=active]:text-primary data-[state=active]:shadow-none h-14 rounded-none border-b-2 border-transparent px-4"
                    >
                      <ShieldAlert className="mr-2 size-4" />
                      敏感词管理
                    </TabsTrigger>
                  </TabsList>
                </div>

                <div className="p-4 md:p-6">
                  <TabsContent value="posts" className="mt-0">
                    <PostsTab />
                  </TabsContent>
                  <TabsContent value="comments" className="mt-0">
                    <CommentsTab />
                  </TabsContent>
                  <TabsContent value="users" className="mt-0">
                    <UsersTab />
                  </TabsContent>
                  <TabsContent value="sensitive" className="mt-0">
                    <SensitiveTab />
                  </TabsContent>
                </div>
              </Tabs>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
};

export default AdminDashboardPage;
