import React, { useState } from 'react';
import { toast } from 'sonner';
import { Loader2 } from 'lucide-react';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { createAdminUser } from '@/api/admin';
import type { ForumUser, CreateUserRequest } from '@shared/api.interface';

interface AddUserDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onSuccess: (user: ForumUser) => void;
}

const AddUserDialog: React.FC<AddUserDialogProps> = ({ open, onOpenChange, onSuccess }) => {
  const [username, setUsername] = useState<string>('');
  const [nickname, setNickname] = useState<string>('');
  const [password, setPassword] = useState<string>('');
  const [submitting, setSubmitting] = useState<boolean>(false);

  const resetForm = (): void => {
    setUsername('');
    setNickname('');
    setPassword('');
  };

  const handleSubmit = async (e: React.FormEvent<HTMLFormElement>): Promise<void> => {
    e.preventDefault();

    if (!username.trim() || username.length < 3 || username.length > 20) {
      toast.error('用户名长度需在3-20字符之间');
      return;
    }
    if (!nickname.trim() || nickname.length > 20) {
      toast.error('昵称长度需在1-20字符之间');
      return;
    }
    if (!password || password.length < 6 || password.length > 50) {
      toast.error('密码长度需在6-50字符之间');
      return;
    }

    setSubmitting(true);
    try {
      const params: CreateUserRequest = {
        username: username.trim(),
        nickname: nickname.trim(),
        password,
      };
      const user = await createAdminUser(params);
      toast.success('用户添加成功');
      onSuccess(user);
      resetForm();
    } catch (error: unknown) {
      const message =
        (error as { response?: { data?: { error?: { message?: string } } } })?.response?.data?.error
          ?.message || '添加失败';
      toast.error(message);
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle>添加用户</DialogTitle>
          <DialogDescription>
            创建一个新的校园社区用户账号，用户可以使用此账号登录发帖。
          </DialogDescription>
        </DialogHeader>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="new-username">用户名 *</Label>
            <Input
              id="new-username"
              placeholder="3-20个字符"
              value={username}
              onChange={(e: React.ChangeEvent<HTMLInputElement>) => setUsername(e.target.value)}
            />
          </div>
          <div className="space-y-2">
            <Label htmlFor="new-nickname">昵称 *</Label>
            <Input
              id="new-nickname"
              placeholder="显示在帖子和评论中的名称"
              value={nickname}
              onChange={(e: React.ChangeEvent<HTMLInputElement>) => setNickname(e.target.value)}
            />
          </div>
          <div className="space-y-2">
            <Label htmlFor="new-password">初始密码 *</Label>
            <Input
              id="new-password"
              type="password"
              placeholder="6-50个字符"
              value={password}
              onChange={(e: React.ChangeEvent<HTMLInputElement>) => setPassword(e.target.value)}
            />
          </div>
          <DialogFooter>
            <Button type="button" variant="outline" onClick={() => onOpenChange(false)}>
              取消
            </Button>
            <Button type="submit" disabled={submitting}>
              {submitting ? (
                <>
                  <Loader2 className="mr-2 size-4 animate-spin" />
                  添加中...
                </>
              ) : (
                '添加用户'
              )}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
};

export default AddUserDialog;
