import request from './auth';
import type {
  Post,
  PostListResponse,
  CategoryCount,
  CreatePostRequest,
  CommentListResponse,
  CreateCommentRequest,
  Comment,
  LikeStatus,
} from '@shared/api.interface';

interface GetPostsParams {
  page: number;
  pageSize: number;
  category?: string;
  keyword?: string;
}

export async function getPosts(params: GetPostsParams): Promise<PostListResponse> {
  const { data } = await request.get<PostListResponse>('/posts', { params });
  return data;
}

export async function getCategoryCounts(): Promise<{ counts: CategoryCount[] }> {
  const { data } = await request.get<{ counts: CategoryCount[] }>('/posts/category-counts');
  return data;
}

export async function getPost(id: string): Promise<Post> {
  const { data } = await request.get<Post>(`/posts/${id}`);
  return data;
}

export async function createPost(params: CreatePostRequest): Promise<Post> {
  const { data } = await request.post<Post>('/posts', params);
  return data;
}

export async function getMyPosts(params: {
  page: number;
  pageSize: number;
}): Promise<PostListResponse> {
  const { data } = await request.get<PostListResponse>('/posts/mine/list', { params });
  return data;
}

export async function getComments(postId: string): Promise<CommentListResponse> {
  const { data } = await request.get<CommentListResponse>(`/posts/${postId}/comments`);
  return data;
}

export async function createComment(
  postId: string,
  content: string,
): Promise<Comment> {
  const params: CreateCommentRequest = { content };
  const { data } = await request.post<Comment>(`/posts/${postId}/comments`, params);
  return data;
}

export async function getLikeStatus(postId: string): Promise<LikeStatus> {
  const { data } = await request.get<LikeStatus>(`/posts/${postId}/like-status`);
  return data;
}

export async function toggleLike(postId: string, shouldLike: boolean): Promise<LikeStatus> {
  if (shouldLike) {
    const { data } = await request.post<LikeStatus>(`/posts/${postId}/like`);
    return data;
  } else {
    const { data } = await request.delete<LikeStatus>(`/posts/${postId}/unlike`);
    return data;
  }
}
