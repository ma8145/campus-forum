import axios from 'axios';
import type {
  AdminLoginRequest,
  AdminLoginResponse,
  AdminPostListResponse,
  AdminCommentListResponse,
  SensitiveWordListResponse,
  SensitiveWord,
  ForumUserListResponse,
  ForumUser,
  CreateUserRequest,
  AdminStats,
} from '@shared/api.interface';

const ADMIN_TOKEN_KEY = 'admin_token';

const adminRequest = axios.create({
  baseURL: '/api/admin',
  timeout: 15000,
});

adminRequest.interceptors.request.use(
  (config) => {
    const token = localStorage.getItem(ADMIN_TOKEN_KEY);
    if (token) {
      config.headers['x-admin-token'] = token;
    }
    return config;
  },
  (error) => Promise.reject(error),
);

adminRequest.interceptors.response.use(
  (response) => response,
  (error) => {
    if (error?.response?.status === 401) {
      localStorage.removeItem(ADMIN_TOKEN_KEY);
      if (!window.location.pathname.startsWith('/admin/login')) {
        window.location.href = '/admin/login';
      }
    }
    return Promise.reject(error);
  },
);

export async function adminLogin(params: AdminLoginRequest): Promise<AdminLoginResponse> {
  const { data } = await adminRequest.post<AdminLoginResponse>('/login', params);
  if (data.token) {
    localStorage.setItem(ADMIN_TOKEN_KEY, data.token);
  }
  return data;
}

export function getAdminToken(): string | null {
  return localStorage.getItem(ADMIN_TOKEN_KEY);
}

export function clearAdminToken(): void {
  localStorage.removeItem(ADMIN_TOKEN_KEY);
}

export async function logoutAdmin(): Promise<void> {
  try {
    await adminRequest.post('/logout');
  } catch {
    // ignore
  }
  clearAdminToken();
}

export async function getAdminStats(): Promise<AdminStats> {
  const { data } = await adminRequest.get<AdminStats>('/stats');
  return data;
}

export async function getAdminPosts(page: number, pageSize: number): Promise<AdminPostListResponse> {
  const { data } = await adminRequest.get<AdminPostListResponse>('/posts', {
    params: { page, pageSize },
  });
  return data;
}

export async function deleteAdminPost(id: string): Promise<void> {
  await adminRequest.delete(`/posts/${id}`);
}

export async function setPostTop(id: string, isTop: boolean): Promise<void> {
  await adminRequest.put(`/posts/${id}/top`, { isTop });
}

export async function getAdminComments(page: number, pageSize: number): Promise<AdminCommentListResponse> {
  const { data } = await adminRequest.get<AdminCommentListResponse>('/comments', {
    params: { page, pageSize },
  });
  return data;
}

export async function deleteAdminComment(id: string): Promise<void> {
  await adminRequest.delete(`/comments/${id}`);
}

export async function getSensitiveWords(page: number, pageSize: number): Promise<SensitiveWordListResponse> {
  const { data } = await adminRequest.get<SensitiveWordListResponse>('/sensitive-words', {
    params: { page, pageSize },
  });
  return data;
}

export async function addSensitiveWord(word: string): Promise<SensitiveWord> {
  const { data } = await adminRequest.post<SensitiveWord>('/sensitive-words', { word });
  return data;
}

export async function deleteSensitiveWord(id: string): Promise<void> {
  await adminRequest.delete(`/sensitive-words/${id}`);
}

export async function getAdminUsers(page: number, pageSize: number): Promise<ForumUserListResponse> {
  const { data } = await adminRequest.get<ForumUserListResponse>('/users', {
    params: { page, pageSize },
  });
  return data;
}

export async function createAdminUser(params: CreateUserRequest): Promise<ForumUser> {
  const { data } = await adminRequest.post<ForumUser>('/users', params);
  return data;
}

export async function deleteAdminUser(id: string): Promise<void> {
  await adminRequest.delete(`/users/${id}`);
}

export async function resetAdminUserPassword(id: string, password: string): Promise<void> {
  await adminRequest.put(`/users/${id}/password`, { password });
}
